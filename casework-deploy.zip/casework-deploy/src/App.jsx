import React, { useState, useRef, useEffect } from "react";

// ─────────────────────────────────────────────────────────────
// CASEWORK PRO · Pipeline de preparación con IA
// 1) Subes tu HdV (PDF/imagen) → la IA la diagnostica y dice qué falta
// 2) Te arma una guía de certificaciones según tu perfil + empresa objetivo
// 3) Genera una entrevista aterrizada en TU experiencia y ESA empresa
// 4) Feedback final con rúbrica
// ─────────────────────────────────────────────────────────────

const C = {
  ink: "#0d0f14", panel: "#151a22", panel2: "#1c232e", border: "#2a323f",
  text: "#ece9e3", muted: "#8a93a3", amber: "#e7b75f", amberDim: "#9c7d3e",
  green: "#74c79a", red: "#e98b73", blue: "#7aa7d6",
};
const FONTS = {
  display: "'Fraunces', Georgia, serif",
  body: "'Hanken Grotesk', system-ui, sans-serif",
  mono: "'JetBrains Mono', monospace",
};

const ROLES = [
  { id: "analysis", label: "Análisis de negocio / datos", desc: "Métricas, diagnóstico, requisitos" },
  { id: "strategy", label: "Estrategia / Consultoría", desc: "Casos tipo MBB, estructura" },
  { id: "finance", label: "Finanzas / FP&A", desc: "Escenarios, rentabilidad, modelado" },
  { id: "ops", label: "Operaciones / Supply Chain", desc: "Procesos, inventarios, proveedores" },
  { id: "growth", label: "Growth / Marketing", desc: "Funnel, CAC/LTV, canales" },
  { id: "custom", label: "Otra área…", desc: "Escríbela tú (RR.HH., compras…)" },
];
const CASE_TYPES = [
  { id: "likely", label: "Lo más probable", desc: "Lo que más te preguntarían según empresa, cargo y tu HdV" },
  { id: "fit", label: "Entrenamiento de Fit", desc: "Háblame de ti, por qué la empresa… a tu medida" },
  { id: "diagnosis", label: "Diagnóstico", desc: "Algo cayó — descubre por qué" },
  { id: "decision", label: "Decisión / Priorización", desc: "Elegir entre opciones o asignar recursos" },
  { id: "sizing", label: "Estimación", desc: "Calcular un mercado / tamaño" },
  { id: "process", label: "Procesos", desc: "Optimizar una operación" },
  { id: "excel", label: "Prueba Excel / datos", desc: "Dataset + tareas y fórmulas" },
];
const FIT_MODES = [
  { id: "round", label: "Ronda completa", desc: "5-6 preguntas seguidas, como entrevista real" },
  { id: "drill", label: "Pregunta por pregunta", desc: "Machaca una hasta clavarla" },
];
const DIFFS = [
  { id: "intern", label: "Intern / Práctica", desc: "Primer acercamiento, mucha guía" },
  { id: "junior", label: "Junior", desc: "Apoyo moderado" },
  { id: "mid", label: "Mid", desc: "Equilibrado" },
  { id: "senior", label: "Senior", desc: "Exigente (sin ser cruel)" },
];
const MODES = [
  { id: "trainer", label: "🎓 Trainer", desc: "Te guía y da pistas hasta que llegues a la respuesta. Sin presión." },
  { id: "real", label: "💼 Entrevista real", desc: "Simulación realista y rigurosa, como el día de la entrevista." },
];
const LANGS = [{ id: "es", label: "Español" }, { id: "en", label: "English" }, { id: "mix", label: "Mezcla" }];
const PERSONAS = [
  { id: "random", label: "🎲 Al azar", desc: "Te toca uno sin saber cuál" },
  { id: "recruiter", label: "Recruiter amable", desc: "Cálido, baja presión", prompt: "PERSONA: a warm, friendly recruiter. Conversational and encouraging, low pressure; focuses on motivation, communication and culture fit; reassures the candidate." },
  { id: "analytical", label: "Manager analítico", desc: "Pide números y lógica", prompt: "PERSONA: a methodical analytical hiring manager. Neutral tone, detail-oriented; constantly asks for the numbers, the logic and the 'so what'. Calm but precise." },
  { id: "vp", label: "VP ejecutivo", desc: "Quiere el titular primero", prompt: "PERSONA: a busy senior executive (VP). Big-picture, impatient with detail; wants the headline/answer FIRST then the reasoning. Cuts off rambling, expects crisp synthesis and business impact." },
  { id: "mbb", label: "Consultor MBB", desc: "Estructura y rigor", prompt: "PERSONA: a top-tier strategy consultant. Highly structured; expects MECE breakdowns, explicit hypotheses, clean quantification and sharp synthesis. Politely demanding about rigor." },
  { id: "tough", label: "Exigente", desc: "Presión alta, te reta", prompt: "PERSONA: a high-pressure, skeptical interviewer who challenges every claim and pushes back hard. Demanding and direct — but ALWAYS professional and respectful, never rude, insulting or personal." },
];
const PERSONA_TIPS = {
  recruiter: "Recruiter amable: conecta y muestra motivación, comunica claro — pero igual estructura, no te confíes.",
  analytical: "Manager analítico: respalda todo con números y lógica explícita; di siempre el 'y por lo tanto'.",
  vp: "VP ejecutivo: da el titular primero, luego el porqué; sé breve y apunta al impacto de negocio.",
  mbb: "Consultor MBB: estructura MECE, hipótesis explícitas y cuantifica; cierra con una síntesis afilada.",
  tough: "Entrevistador exigente: mantén la calma, defiende con datos y no te derrumbes ante la presión.",
};
const PLAYBOOKS = [
  { id: "diagnosis", title: "Diagnóstico",
    framework: ["Aclara la métrica y el periodo: ¿qué cayó, cuánto y desde cuándo?", "Desagrega (segmento, canal, geografía, producto) para aislar dónde está el problema.", "Formula hipótesis priorizadas de la causa, de más a menos probable.", "Pide datos para probar cada hipótesis y confirma la causa raíz.", "Cuantifica el impacto y propón una acción."],
    tips: ["Desagrega antes de concluir: el promedio esconde el problema.", "Usa una fórmula de drivers (ej. Ingreso = Precio × Volumen).", "Distingue causa interna vs. externa (mercado/competencia)."],
    errors: ["Saltar a la solución sin diagnosticar.", "Quedarte en una sola hipótesis.", "No cuantificar el tamaño del problema."] },
  { id: "decision", title: "Decisión / Priorización",
    framework: ["Define el objetivo y el criterio de decisión.", "Lista las opciones y los criterios para compararlas (costo, tiempo, riesgo, impacto).", "Evalúa cada opción contra los criterios, con datos.", "Recomienda una opción y di bajo qué condición cambiarías.", "Para priorizar: ordena por impacto vs. esfuerzo."],
    tips: ["Haz explícitos tus criterios antes de elegir.", "Da una recomendación clara, no 'depende'.", "Incluye una condición de quiebre con un disparador medible."],
    errors: ["Elegir solo por costo sin ver impacto/riesgo.", "No dar recomendación final.", "Comparar opciones sin criterios definidos."] },
  { id: "sizing", title: "Estimación",
    framework: ["Aclara qué estás estimando y las unidades.", "Elige enfoque: top-down (de población) o bottom-up (de unidades).", "Descompón en factores multiplicables y dilos en voz alta.", "Usa supuestos razonables y redondos; justifícalos.", "Suma, haz un sanity check y da un rango."],
    tips: ["Piensa en voz alta: importa el método, no el número exacto.", "Usa números redondos para calcular rápido.", "Verifica el orden de magnitud al final."],
    errors: ["Buscar el número 'exacto' en vez del método.", "Supuestos sin justificar.", "No hacer sanity check."] },
  { id: "process", title: "Procesos",
    framework: ["Mapea el proceso de inicio a fin.", "Identifica el cuello de botella (el paso que más demora/cuesta).", "Cuantifica: tiempos, costos y tasas de error por paso.", "Propón mejoras a la restricción (eliminar, automatizar, paralelizar).", "Estima el impacto de la mejora."],
    tips: ["Optimiza primero la restricción, no todo el proceso.", "Separa tiempo de valor agregado vs. desperdicio.", "Cuantifica antes y después."],
    errors: ["Optimizar pasos que no son el cuello de botella.", "No medir el proceso actual.", "Proponer mejoras sin estimar impacto."] },
  { id: "excel", title: "Prueba Excel / datos",
    framework: ["Entiende el dataset: columnas, tipos, qué representa cada fila.", "Limpia mentalmente: duplicados, formatos, vacíos.", "Elige la fórmula correcta (SUMIFS, XLOOKUP, INDEX/MATCH, tablas dinámicas).", "Calcula y verifica con un caso pequeño.", "Interpreta: ¿qué dice el número para el negocio?"],
    tips: ["Di la fórmula y por qué, no solo el resultado.", "Prefiere XLOOKUP / INDEX-MATCH sobre un VLOOKUP frágil.", "Cierra con la lectura de negocio, no solo el cálculo."],
    errors: ["Dar el resultado sin la fórmula.", "Referencias que se rompen al copiar (faltan $).", "No interpretar el dato."] },
  { id: "fit", title: "Fit & Motivación",
    framework: ["Prepara tu 'háblame de ti' en 60-90s: presente → trayectoria → por qué aquí.", "Para 'por qué la empresa': 2-3 razones específicas y reales (no clichés).", "Responde behavioral con STAR: Situación, Tarea, Acción, Resultado (con números).", "Ancla cada respuesta en un logro real de tu HdV.", "Cierra mostrando encaje con el rol y la cultura."],
    tips: ["Sé específico y auténtico; evita respuestas genéricas.", "Cuantifica el resultado de tus historias.", "Investiga la empresa: demuestra que la conoces."],
    errors: ["Clichés en 'por qué nosotros'.", "Historias sin resultado medible.", "Divagar sin estructura STAR."] },
];

// ── Anthropic API ────────────────────────────────────────────
// DEPLOY VERSION: calls OUR backend (/api/claude), never Anthropic directly.
// The backend holds the API key and picks the model:
//   task: "light" → Haiku (cheap; CV extraction, terms)  ·  task: "deep" (default) → Sonnet (interview, feedback)
async function callClaude({ messages, maxTokens = 1000, tools, task = "deep" }) {
  const body = { messages, maxTokens, task };
  if (tools) body.tools = tools;
  let lastErr = "";
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch("/api/claude", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (res.ok) {
      const data = await res.json();
      const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
      if (!text) throw new Error("respuesta vacía");
      return text;
    }
    let detail = "";
    try { detail = (await res.text()).slice(0, 160); } catch (_) {}
    lastErr = "HTTP " + res.status + (detail ? " · " + detail : "");
    // Retry on transient overload / rate limit
    if (res.status === 529 || res.status === 429 || res.status >= 500) {
      await new Promise((r) => setTimeout(r, 1200 * (attempt + 1)));
      continue;
    }
    throw new Error(lastErr);
  }
  throw new Error("El servicio está saturado (529). Espera un momento y reintenta. " + lastErr);
}
function repairJSON(raw) {
  // Best-effort repair of a truncated JSON object: close open strings/arrays/objects.
  let c = raw.replace(/```json|```/g, "").trim();
  const start = c.indexOf("{");
  if (start > 0) c = c.slice(start);
  let out = "", stack = [], inStr = false, esc = false;
  for (let i = 0; i < c.length; i++) {
    const ch = c[i];
    out += ch;
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === "{" || ch === "[") stack.push(ch);
    else if (ch === "}" || ch === "]") stack.pop();
  }
  if (inStr) out += '"';                       // close a dangling string
  out = out.replace(/,\s*$/, "");              // drop trailing comma
  out = out.replace(/"[^"]*"\s*:\s*$/, "");    // drop a dangling "key": with no value
  out = out.replace(/,\s*$/, "");
  while (stack.length) { out += stack.pop() === "{" ? "}" : "]"; }
  return out;
}
function parseJSON(raw) {
  let c = raw.replace(/```json|```/g, "").trim();
  const s = c.indexOf("{"), e = c.lastIndexOf("}");
  if (s !== -1 && e !== -1) c = c.slice(s, e + 1);
  try { return JSON.parse(c); }
  catch (_) { return JSON.parse(repairJSON(raw)); }   // salvage a truncated response
}

// ── Prompts ──────────────────────────────────────────────────
function cvDiagnosticSystem(target, roleLabel) {
  const jd = target.jobDesc ? `\n\nDescripción de la vacante a la que aplica (evalúa el AJUSTE contra esto):\n"""${target.jobDesc.slice(0, 1300)}"""` : "";
  const req = target.requirements ? `\n\nREQUISITOS DEL CARGO (evalúa explícitamente si el candidato es apto contra estos):\n"""${target.requirements.slice(0, 900)}"""` : "";
  return `You are an expert recruiter and career coach. Analyze the candidate's CV (attached) for a "${target.role || roleLabel}" role${target.company ? ` at ${target.company}` : ""}.${jd}${req}

TONE: be honest but HUMAN and constructive. The goal is to PREPARE the candidate, not to disqualify them. Frame gaps as growth paths, not eliminators — e.g. instead of "no sabe Python", write "puede reforzar Python; su perfil lógico-analítico facilita aprenderlo". Recognize transferable strengths.

Respond in Spanish, VALID JSON ONLY, no code fences. Schema:
{
 "name":"<nombre completo del candidato, tal como aparece en el CV>",
 "level":"<Intern|Junior|Mid|Senior — estimación>",
 "summary":"<2 frases sobre el perfil>",
 "experience":["<max 3: experiencias/logros CONCRETOS que un entrevistador podría mencionar, <16 palabras, con cifras si las hay>"],
 "strengths":["<max 3, concretas>"],
 "gaps":["<max 3: brechas formuladas como oportunidad de mejora, no como descalificadores>"],
 "cvFixes":["<max 3: mejoras al documento>"],
 "matchRoles":["<max 4: otros cargos REALES del mercado con los que su perfil hace match, según su experiencia — ej. 'Analista de operaciones', 'Coordinador de planeación'>"],${target.requirements ? `
 "readiness":{"label":"<Apto | Apto con brechas menores | Aún en desarrollo>","meets":["<max 3 requisitos que SÍ cumple>"],"toClose":["<max 3 requisitos por cerrar, en tono de mejora alcanzable>"],"note":"<1 frase honesta y motivadora sobre su aptitud para el cargo>"},` : ""}
 "fit":{"score":<0-100, % de ajuste a la vacante/rol>,"matches":["<max 3, lo que SÍ encaja con la vacante>"],"missing":["<max 3, lo que la vacante pide y no aparece, en tono de mejora>"]}
}
Be specific to what's actually in the CV. Keep each item under 16 words.`;
}
function cvAdaptSystem(target, roleLabel) {
  const jd = target.jobDesc
    ? `\n\nDESCRIPCIÓN DE LA VACANTE (úsala como guía principal):\n"""${target.jobDesc.slice(0, 1600)}"""\n\nADAPTA FUERTEMENTE A ESTA DESCRIPCIÓN (sin inventar):\n- Identifica lo que la vacante más valora (responsabilidades, skills, métricas) y PRIORIZA y ORDENA el contenido de la HdV para que eso aparezca primero y más visible.\n- Donde el candidato YA tenga esa experiencia, redáctala usando el MISMO vocabulario/keywords de la descripción (útil para filtros ATS) — pero solo si es verdad.\n- El resumen y los bullets deben hablarle directamente a lo que pide la vacante; omite lo que no aporte a este rol.\n- NO agregues skills ni logros que la vacante pide pero el candidato no tiene.`
    : "";
  return `You are a professional CV writer. You receive the candidate's REAL CV (attached) and a target role. Produce a CONCISE, well-ordered CV designed to fit on ONE page.

ABSOLUTE RULE — ZERO FABRICATION: Use ONLY information that already appears in the attached CV. Do NOT invent or add any experience, achievement, metric, employer, date, title, education, skill, certification or summary that is not in the document.

BE A SERIOUS EDITOR (this is key):
- ADAPT TO THE PROFESSION/INDUSTRY of the target role — do NOT default to private corporate / business language. Use the conventions, vocabulary and emphasis of THAT field: a lawyer's CV speaks of jurisdictions, litigation, areas of law; an engineer's of projects, methods, technical tools; public sector, academia, health, design, etc. each have their own register. Match it.
- REMOVE entirely any experience, bullet or skill that is useless or irrelevant for THIS role — do not keep it just to fill space. A focused, relevant CV beats a complete one.
- Lead with and EMPHASIZE the skills and experiences that matter most for the role; put the strongest, most relevant content first.
- Reword existing bullets so each one clearly shows value for THIS role (action verb + what + result/number when present).
- If the role wants something the CV lacks, DO NOT add it. Leave a section empty if there's nothing relevant.

Target role: "${target.role || roleLabel}"${target.company ? ` at ${target.company}` : ""}.${jd}

To fit ONE page, be tight: summary max 3 lines; at most 4 experiences, each with at most 3 short bullets (start bullets with an action verb, include real numbers if present). Respond in Spanish, VALID JSON ONLY, no code fences:
{
 "name":"<nombre completo>",
 "headline":"<título profesional corto, ej. 'Analista de Operaciones · Supply Chain'>",
 "contact":"<ciudad · correo · teléfono · LinkedIn — SOLO lo que aparezca en el CV>",
 "summary":"<2-3 líneas, construidas SOLO con hechos reales del CV, enfocadas a la vacante>",
 "experience":[{"role":"<cargo>","org":"<empresa>","dates":"<fechas>","bullets":["<logro/responsabilidad real, conciso, alineado a la vacante>"]}],
 "education":[{"title":"<título>","org":"<institución>","dates":"<fechas>"}],
 "skills":["<habilidad/herramienta real, priorizando las que pide la vacante>"],
 "certifications":["<solo si aparecen en el CV; si no, deja []>"],
 "changes":["<lista de los cambios CONCRETOS que hiciste al adaptar: qué quitaste y por qué, qué resaltaste, qué reordenaste, qué reformulaste — max 5, cada uno <18 palabras>"]
}`;
}
function termsSystem(target, roleLabel) {
  const jd = target.jobDesc ? `, según esta descripción de vacante:\n"""${target.jobDesc.slice(0, 1300)}"""` : "";
  return `You are an interview coach. List terms, concepts, frameworks, metrics and acronyms that could REALISTICALLY come up in an interview for a "${target.role || roleLabel}" role${target.company ? ` at ${target.company}` : ""}${jd} — the kind an interviewer might ask about, or that the candidate should drop naturally to sound fluent.

STRICT RULES:
- Pick NON-OBVIOUS, role/industry-specific items. Do NOT include common-knowledge tools or words everyone already knows (NEVER define Excel, email, PowerPoint, "reunión", "base de datos", etc.). If a tool matters, pick a specific technique/concept inside it, not the tool itself.
- Favor methodologies, domain KPIs/metrics, frameworks, sector jargon and acronyms specific to THIS role and company.
- Frame each definition for interview use: what it means in this context + when/how it shows up.

Respond in Spanish, VALID JSON ONLY, no fences:
{"terms":[{"term":"<término/sigla>","definition":"<qué es, en contexto del rol, <20 palabras>","formula":"<si es un KPI o métrica, su fórmula exacta — ej. 'OTIF = entregas a tiempo y completas / total entregas'; si NO aplica, deja \\"\\">","whyMatters":"<cómo o cuándo aparece en la entrevista, <14 palabras>"}]}
Give 6-9, the most important first.`;
}
function certSystem(target, roleLabel) {
  return `You are a career coach. Given a candidate profile and a target, recommend certifications/courses that close gaps and strengthen candidacy for "${target.role || roleLabel}"${target.company ? ` at ${target.company}` : ""}. Respond in Spanish, VALID JSON ONLY, no fences. Schema:
{
 "certifications":[
   {"name":"<cert/curso>","provider":"<quién lo da>","why":"<por qué le sirve, <14 palabras>","priority":"<Alta|Media|Baja>"}
 ]
}
Give 4-6, ordered by priority. Prefer recognized, relevant credentials (analytics, BI, the domain, the target company's stack).`;
}
function interviewSystem(cfg, roleLabel, target, profile, companyContext) {
  const lang = {
    es: "Conduce TODA la entrevista en español.",
    en: "Conduct the ENTIRE interview in English.",
    mix: "Switch naturally between Spanish and English, as in real interviews at multinationals in Latin America.",
  }[cfg.language];
  const flavor = {
    likely: "the MOST LIKELY case or question this candidate would realistically face for this exact role and company, based on the job description and their CV. Pick what an interviewer there would actually ask.",
    fit: "FIT",
    diagnosis: "a diagnostic case (a metric moved unexpectedly; find root cause).",
    decision: "a decision OR prioritization case — either choosing between options (e.g. build vs buy, go/no-go) or allocating limited resources across competing fronts; pick whichever fits the role.",
    sizing: "an estimation / market-sizing case.",
    process: "a process-optimization / operations case with a hidden bottleneck.",
    excel: "EXCEL",
  }[cfg.caseType];

  // Real difficulty scaled to seniority — clearly differentiated, junior is NOT trivial
  const levelSpec = {
    intern: "LEVEL — INTERN/entry: accessible but REAL. One clear problem with a couple of variables; teach as you go, but it must resemble an actual entry-level case, not a toy.",
    junior: "LEVEL — JUNIOR: a real, demanding problem with 2-3 interacting parts. Expect structured reasoning and quantification. This must feel like a case a real company would actually pose — NOT simplified or baby-easy.",
    mid: "LEVEL — MID: genuinely challenging, the kind a real company uses to filter. Multiple interacting factors, real ambiguity, prioritization, quantification and explicit trade-offs.",
    senior: "LEVEL — SENIOR: hard, ambiguous and strategic — at the level a real company would actually test a senior hire. Multi-layered, with second-order effects, incomplete data and judgment calls. Generic or textbook answers must be clearly insufficient.",
  }[cfg.difficulty];
  const realism = "REALISM: calibrate the case to what a REAL company in this sector would actually ask for this level — experienced candidates find generic cases too easy, so add real-world texture (concrete numbers, constraints, conflicting data, operational detail). Never water it down.";
  const closing = cfg.mode === "real"
    ? `CLOSING (REAL interview): once you've covered the fit/case (after ~3-4 substantive questions), bring the interview to a realistic CLOSE, like an actual interviewer would: invite the candidate to ask you 1-2 questions, answer briefly, then thank them BY NAME and give a short professional sign-off (e.g. "Con esto terminamos. Gracias por tu tiempo, te contaremos los siguientes pasos del proceso."). Make it clear the interview has ENDED. Do NOT give coaching or scores in real mode — that's what the feedback is for. Then add one line telling them to press "Terminar · feedback" to get their evaluation.`
    : `WRAP-UP (TRAINER): once covered, give a brief coaching close — what they did well and the top 1-2 things to sharpen — and invite them to press "Terminar · feedback" for the full evaluation.`;

  const isConsulting = cfg.role === "strategy";
  const consult = isConsulting ? " CONSULTING context (MBB-style): demand clean MECE structure, explicit frameworks, sharp quantification and crisp synthesis — be noticeably more rigorous and expect more." : "";

  // Guidance scales with mode AND seniority: less hand-holding the more senior, especially in real mode
  let guidance;
  if (cfg.mode === "trainer") {
    guidance = "MODE — TRAINER/COACH: actively teach. If the candidate struggles or loops, offer a hint, a partial framework or a leading question; be warm and encouraging. (At senior level, guide toward depth and rigor, not basics.)";
  } else {
    const g = {
      intern: "realistic but kind — if they're stuck after ~2 tries, give a gentle nudge.",
      junior: "realistic — let them work; only a small nudge if they're genuinely stuck after a couple of tries.",
      mid: "minimal guidance — expect them to drive; mostly just clarify and provide data when asked.",
      senior: "almost NO hand-holding — the candidate must lead entirely. Only answer clarifying questions and give data when asked; do NOT hint at the approach or rescue them.",
    }[cfg.difficulty];
    guidance = "MODE — REALISTIC INTERVIEW: a busy, to-the-point interviewer. SHORT messages (2-4 sentences + one direct question), no preamble, no recapping. Rigorous but respectful, never cruel. Guidance: " + g;
  }

  const personaSpec = (PERSONAS.find((p) => p.id === cfg.persona)?.prompt) || "";

  // In Trainer, open with a short briefing on what this company's interview process is really like
  const briefing = cfg.mode === "trainer"
    ? `TRAINER BRIEFING (do this FIRST, before any question): give a SHORT briefing (4-6 sentences, use **bold** sub-points) on what an interview for "${target.role || roleLabel}" at ${target.company || "this kind of company"} is really like — based on what you genuinely know about ${target.company || "this company"} and its sector (and the company research above if present). Cover: the typical STYLE/format (e.g. MBB = structured candidate-led cases; Big Four = mix of fit + technical; consumer multinational = competency/STAR-heavy; startup = practical & fast), what they really EVALUATE, HOW the candidate should open/approach it, and 1-2 common mistakes. If you do NOT reliably know this specific company's process, say so honestly and give the best guidance for that sector/firm type instead of inventing specifics. Then say "Empecemos" and start the practice. Adapt your questions to this style.`
    : "";

  // Canonical bank of real fit questions for ops/analyst/CS/supply-chain roles
  const fitBank = `BANCO DE PREGUNTAS DE FIT (elige las más pertinentes, una a la vez): 1) Háblame de ti (la más importante: claridad, estructura, narrativa coherente). 2) ¿Por qué quieres este rol? (¿entiende el trabajo o aplicó por nombre/salario?). 3) ¿Por qué ${target.company || "esta empresa"}? (investigación previa, motivación real, encaje cultural). 4) ¿Por qué cambias de área? (clave si su HdV es de un área distinta al rol objetivo). 5) Un problema difícil que manejaste (ownership, calma, estructura). 6) Un conflicto con alguien (madurez; la clave es cómo lo resolvió, no quién "ganó"). 7) Tu mayor logro (idealmente con impacto medible: ahorro, reducción de tiempos, automatización). 8) Tu mayor debilidad (autoconciencia + mejora real, no perfección). 9) ¿Cómo manejas prioridades/presión? 10) ¿Dónde te ves en 3-5 años? (ambición razonable y coherencia). 11) ¿Por qué deberíamos contratarte? (resumen de valor). 12) Behavioral STAR: una vez que fallaste, una situación ambigua, liderar sin autoridad, un cliente difícil, una decisión con poca información. Evalúa las respuestas behavioral con STAR (Situación, Tarea, Acción, Resultado con números).`;

  // Fit/behavioral questions are ALWAYS part of a real interview — include them in both modes
  const fitOpening = cfg.mode === "real"
    ? `REALISTIC INTERVIEW FLOW: begin with a brief FIT phase BEFORE the case. Your FIRST message is a short greeting (by name if known) + ONE fit question — usually "Háblame de ti". Then ask 2-4 more fit questions ONE at a time, chosen from the bank below as fits the candidate (always include "por qué este rol/empresa", and "por qué cambias de área" if their CV background differs from the target role), reacting briefly to each. THEN move to the case with its anchor. Keep everything concise.\n${fitBank}`
    : `FIT COACHING FIRST: fit questions are ALWAYS asked in real interviews, so coach them first. Greet (by name if known), then ask ONE fit question at a time from the bank below — start with "Háblame de ti". After each answer, COACH it: what works, what to improve, and (especially for junior/intern) model a stronger version using their real CV and the company. Cover 3-4 fit questions (always include "por qué este rol", "por qué la empresa", and "por qué cambias de área" if relevant), THEN move to the case with its anchor.\n${fitBank}`;

  const ctx = [];
  const country = (target.country || "Colombia").trim();
  ctx.push(`Set the case in ${country}. Use ${country}'s real cities, local currency, and market context. Do NOT default to Mexico or any other country.`);
  ctx.push(`NUMBER FORMATTING: when a value is money (COP or USD), show it as currency with its label, e.g. "COP $48.500.000" or "USD $1,200". For NON-currency numbers (counts, units, days, ratios), do NOT use thousands separators and use a decimal point ONLY for real decimals — e.g. write 1500 (not 1.500), and 4.5 only when it's four-point-five.`);
  if (profile && profile.name) ctx.push(`The candidate's name is ${profile.name} — greet them by their first name to make it realistic.`);
  if (target.company) ctx.push(`This is for a role at ${target.company}. Use ${target.company}'s REAL industry/context.`);
  if (companyContext) ctx.push(`REAL CONTEXT about ${target.company || "the company"} (from research — use it to ground the case, the "why this company" discussion, and to make the scenario authentic; if it's a small/specific company, build the case around what it actually does):\n"""${companyContext.slice(0, 1400)}"""`);
  if (target.role) ctx.push(`Target role / cargo: "${target.role}". Tailor the scenario and questions to this specific role's real responsibilities, not just the generic family.`);
  if (target.jobDesc) ctx.push(`Job description for the role:\n"""${target.jobDesc.slice(0, 1300)}"""\nGround the case and questions in the responsibilities, skills and metrics this description emphasizes.`);
  if (profile && profile.summary) {
    const exp = (profile.experience || profile.strengths || []).join("; ");
    ctx.push(`Candidate background from their CV — profile: ${profile.summary}${exp ? ` Experience on record: ${exp}.` : ""} Use this background ONLY when it is genuinely RELEVANT and TRANSFERABLE to the target role "${target.role || roleLabel}". Do NOT force in experience that doesn't fit the role (e.g. do not ask about supply-chain OTD metrics in an HR interview). If a past experience isn't useful for this role, ignore it. When relevant, you may reference it by name to make questions concrete; otherwise focus on the role's own competencies. Calibrate difficulty to their level.`);
  }

  if (flavor === "FIT") {
    const sub = cfg.fitMode === "drill"
      ? "FORMAT — DEEP DRILL: work ONE question at a time and let the candidate retry until it's strong. Start with 'Háblame de ti'. After their answer, coach it thoroughly, then either let them redo it or move to the next most relevant question when they say they're ready."
      : "FORMAT — FULL ROUND: run a realistic fit round of 5-6 questions, ONE at a time, chosen from the bank as fits this candidate. React briefly to each during the round.";
    return `You are running a FIT / BEHAVIORAL interview practice for a ${roleLabel} position. ${lang}
${ctx.join(" ")}
${guidance}${consult} ${personaSpec}
${briefing}
${sub}

This is FIT ONLY — there is NO business case. Tailor EVERY question TIGHTLY to this exact role and company, using the role, the job description, the candidate's CV and the REAL company context above. The "why this company" and "why this role" answers must be probed against SPECIFIC, real facts about ${target.company || "the company"} and the role — not generic statements; if the candidate is generic, push for specifics. Adapt the question mix to the role (e.g. customer-facing roles → client/conflict stories; ops/supply → pressure & prioritization; analyst → structured thinking & measurable impact).

${fitBank}

${cfg.mode === "real"
  ? "REALISTIC MODE: concise and professional, minimal coaching during the round; keep messages short."
  : "TRAINER MODE: after each answer, COACH it — what works, what to improve, and model a STRONGER version using their real CV and the real company facts; especially thorough for intern/junior."}

${closing}

Begin with a short greeting${profile && profile.name ? ` to ${profile.name}` : ""} and your first fit question.`;
  }

  if (flavor === "EXCEL") {
    return `You are a practical data-skills assessor giving a hands-on EXCEL / data test for a ${roleLabel} position. ${lang}
${ctx.join(" ")}
${guidance}${consult} ${personaSpec}
${briefing}
${levelSpec}

YOUR FIRST MESSAGE must contain, in this order:
1. A one-line scenario (a realistic company in ${country} + what the data is).
2. A realistic dataset of 8-12 rows as a markdown table (relevant to ${roleLabel}${target.company ? ` / ${target.company}` : ""}, using ${country}'s context and currency). Scale the difficulty of the tasks to the level above.
3. 4-6 numbered TASKS, each phrased as a clear, self-contained question. Include at least TWO that require an actual Excel formula (e.g. SUMIFS, XLOOKUP/VLOOKUP, INDEX/MATCH, pivot logic, % growth, weighted average) and one or two interpretation/insight questions.
Then tell the candidate they can press "Descargar Excel con la prueba" below: the file contains the data and a table with columns «# · Pregunta · Tu respuesta · Fórmula usada». They fill it in, copy the table and paste it back here for evaluation (or just answer in the chat).

GRADING RULES:
- When the candidate pastes back the filled answer table (or answers inline), evaluate EACH question and reply with a markdown RESULTS TABLE with columns: "#" | "Tu respuesta" | "¿Correcto?" (✓/✗/parcial) | "Respuesta correcta" | "Fórmula correcta". Then add 1-2 lines of overall feedback and the top thing to improve.
- Check correctness rigorously, including whether their Excel formula would actually work (syntax + references + logic).
- Be honest but encouraging: frame mistakes as fixable, never as disqualifiers.
- Stay in character as the assessor. No meta-commentary.

Begin now with the scenario, the data table, and the tasks.`;
  }

  return `You are an interviewer running a live CASE INTERVIEW for a ${roleLabel} position. ${lang}
${ctx.join(" ")}
${guidance}${consult} ${personaSpec}
${briefing}
${levelSpec}
${realism}
${fitOpening}

CASE: Invent ${flavor} Give the company a memorable name (use ${target.company || "a realistic company"}). Embed ONE hidden detail that rewards critical thinking. Match the case's complexity to the LEVEL and REALISM above — do not make a senior case junior-easy, nor a junior case trivially simple.

RULES:
1. Present the case BRIEFLY (after the fit phase if there is one): a 2-3 sentence scenario plus a CONCRETE ANCHOR (one key fact, a small number, OR a suggested starting structure) so the candidate isn't guessing blindly, then ask how they'd approach it. No walls of text.
2. After the anchor, give further data when the candidate asks for something relevant, in markdown tables. Don't dump everything at once, but don't withhold the basics either.
3. If they jump straight to a final solution before any structure, redirect them to structure first — how much you hint is set by the Guidance above (heavy in Trainer, almost none for senior in Real).
4. ALWAYS respond directly to what the candidate ACTUALLY said: acknowledge their specific points by name, build on or challenge them, and adapt your next question to their answer. Never ignore their response or railroad a fixed script.
5. BE HUMAN, not a know-it-all machine. Your job is to PREPARE the candidate, never to make them feel stupid. When they lack a skill or make a mistake, do NOT treat it as an automatic disqualifier — explore it constructively: ask if they'd be willing to learn it, point to their transferable strengths (e.g. "no dominas Python, pero tienes un perfil lógico-analítico fuerte que lo facilita"). Real people make mistakes even when they're qualified; stay encouraging while honest.
6. KEEP THE CASE TIGHT: cover it in roughly 3-4 substantive questions/exchanges, then move to a final synthesis/recommendation and signal the case is wrapping up. Do NOT drag it out with endless follow-ups — a long, repetitive case bores and frustrates the candidate instead of teaching. Quality and depth over quantity.
7. Ask focused "why" follow-ups; acknowledge good reasoning briefly, then build on it.
8. One main question per message; keep it focused; use **bold** and tables.
9. Stay in character. No meta-commentary.

${closing}

${cfg.mode === "real" ? "Begin with the FIT phase: a short greeting + your first fit question. Present the case only AFTER the fit questions." : "Begin by presenting the case WITH its starting anchor."}`;
}
function evalSystem(cfg) {
  const L = cfg.language === "en" ? "English" : "Spanish";
  if (cfg.caseType === "fit") {
    return `Expert evaluator of FIT / behavioral interviews. You get a transcript; evaluate ONLY the candidate. Write in ${L}. VALID JSON ONLY, no fences:
{"overall":<0-100>,"verdict":"<one sentence>","dimensions":[{"name":"Narrativa / estructura","score":<0-5>,"comment":"<<16 words>"},{"name":"Método STAR","score":<0-5>,"comment":"..."},{"name":"Especificidad","score":<0-5>,"comment":"..."},{"name":"Autenticidad","score":<0-5>,"comment":"..."},{"name":"Conocimiento de la empresa","score":<0-5>,"comment":"..."},{"name":"Impacto medible","score":<0-5>,"comment":"..."}],"strengths":["<max 3>"],"improvements":["<max 3, actionable>"]}
Be honest and specific, but ENCOURAGING and developmental: frame weaknesses as fixable growth areas, never as disqualifiers; help the candidate improve without making them feel inadequate.`;
  }
  return `Expert evaluator of case interviews. You get a transcript; evaluate ONLY the candidate. Write in ${L}. VALID JSON ONLY, no fences:
{"overall":<0-100>,"verdict":"<one sentence>","dimensions":[{"name":"Estructura","score":<0-5>,"comment":"<<16 words>"},{"name":"Hipótesis","score":<0-5>,"comment":"..."},{"name":"Uso de datos","score":<0-5>,"comment":"..."},{"name":"Pensamiento crítico","score":<0-5>,"comment":"..."},{"name":"Recomendación","score":<0-5>,"comment":"..."},{"name":"Comunicación","score":<0-5>,"comment":"..."}],"strengths":["<max 3>"],"improvements":["<max 3, actionable>"]}
Be honest and specific, but ENCOURAGING and developmental: frame weaknesses as fixable growth areas, never as disqualifiers; help the candidate improve without making them feel inadequate.`;
}
function planSystem(cfg) {
  const L = cfg.language === "en" ? "English" : "Spanish";
  return `You are a case-interview coach. Given the candidate's weak areas, design a concrete, PRACTICAL practice plan to improve them. Write in ${L}. VALID JSON ONLY, no fences:
{"plan":[{"area":"<dimensión a mejorar>","drill":"<ejercicio concreto y repetible que se hace solo, <30 palabras>","example":"<un ejemplo o prompt para arrancar, <22 palabras>"}],"habit":"<un hábito/rutina semanal corto>"}
Focus on the 2-4 weakest areas. Drills must be specific, doable alone, and tied to the actual gaps.`;
}

// ── Markdown (tables, bold, lists) ───────────────────────────
function renderInline(t, k) {
  return t.split(/(\*\*[^*]+\*\*)/g).map((p, i) =>
    p.startsWith("**") && p.endsWith("**")
      ? <strong key={k + i} style={{ color: C.text, fontWeight: 700 }}>{p.slice(2, -2)}</strong>
      : <span key={k + i}>{p}</span>);
}
function Markdown({ text }) {
  const lines = (text || "").split("\n"); const blocks = []; let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.trim().startsWith("|") && line.includes("|")) {
      const tbl = []; while (i < lines.length && lines[i].trim().startsWith("|")) { tbl.push(lines[i]); i++; }
      const rows = tbl.map((r) => r.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim()))
        .filter((r) => !r.every((c) => /^:?-+:?$/.test(c) || c === ""));
      blocks.push({ type: "table", rows, key: "b" + i }); continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      const items = []; while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*[-*]\s+/, "")); i++; }
      blocks.push({ type: "ul", items, key: "b" + i }); continue;
    }
    if (line.trim() === "") { i++; continue; }
    blocks.push({ type: "p", text: line, key: "b" + i }); i++;
  }
  return <div>{blocks.map((b) => {
    if (b.type === "table") {
      const [head, ...body] = b.rows;
      return <div key={b.key} style={{ overflowX: "auto", margin: "10px 0" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13, fontFamily: FONTS.mono }}>
          <thead><tr>{head.map((h, j) => <th key={j} style={{ textAlign: "left", padding: "7px 10px", borderBottom: `1px solid ${C.amberDim}`, color: C.amber, fontWeight: 600 }}>{h}</th>)}</tr></thead>
          <tbody>{body.map((r, ri) => <tr key={ri}>{r.map((c, ci) => <td key={ci} style={{ padding: "6px 10px", borderBottom: `1px solid ${C.border}`, color: C.text }}>{renderInline(c, b.key + ri + ci)}</td>)}</tr>)}</tbody>
        </table></div>;
    }
    if (b.type === "ul") return <ul key={b.key} style={{ margin: "8px 0", paddingLeft: 18 }}>{b.items.map((it, j) => <li key={j} style={{ marginBottom: 4, lineHeight: 1.55 }}>{renderInline(it, b.key + j)}</li>)}</ul>;
    return <p key={b.key} style={{ margin: "7px 0", lineHeight: 1.6 }}>{renderInline(b.text, b.key)}</p>;
  })}</div>;
}

// ── small UI ─────────────────────────────────────────────────
function Choice({ active, onClick, label, desc }) {
  return <button onClick={onClick} style={{ textAlign: "left", padding: "12px 14px", borderRadius: 10, cursor: "pointer", background: active ? "rgba(231,183,95,0.10)" : C.panel2, border: `1px solid ${active ? C.amber : C.border}`, transition: "all .18s", width: "100%" }}>
    <div style={{ fontWeight: 600, fontSize: 14, color: active ? C.amber : C.text }}>{label}</div>
    {desc && <div style={{ fontSize: 12, color: C.muted, marginTop: 3, lineHeight: 1.4 }}>{desc}</div>}
  </button>;
}
function Pill({ active, onClick, children }) {
  return <button onClick={onClick} style={{ padding: "8px 15px", borderRadius: 999, cursor: "pointer", fontSize: 13.5, fontWeight: 600, background: active ? C.amber : "transparent", color: active ? C.ink : C.muted, border: `1px solid ${active ? C.amber : C.border}`, transition: "all .18s" }}>{children}</button>;
}
function Section({ title, children }) {
  return <div className="cw-fade" style={{ marginBottom: 22 }}>
    <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 2, color: C.amber, marginBottom: 10 }}>{title}</div>{children}
  </div>;
}
function Card({ title, color, items, icon }) {
  return <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: "15px 17px" }}>
    <div style={{ fontWeight: 700, fontSize: 13.5, color, marginBottom: 9 }}>{title}</div>
    {(items || []).map((it, i) => <div key={i} style={{ display: "flex", gap: 9, marginBottom: 7, fontSize: 13.5, lineHeight: 1.5 }}>
      <span style={{ color, flexShrink: 0 }}>{icon}</span><span style={{ color: C.text }}>{it}</span></div>)}
  </div>;
}
function ScoreRing({ value }) {
  const v = Math.max(0, Math.min(100, value || 0)); const r = 34, circ = 2 * Math.PI * r, off = circ - (v / 100) * circ;
  return <div style={{ position: "relative", width: 86, height: 86, flexShrink: 0 }}>
    <svg width="86" height="86" style={{ transform: "rotate(-90deg)" }}>
      <circle cx="43" cy="43" r={r} fill="none" stroke={C.panel2} strokeWidth="7" />
      <circle cx="43" cy="43" r={r} fill="none" stroke={C.amber} strokeWidth="7" strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={off} style={{ transition: "stroke-dashoffset 1s" }} />
    </svg>
    <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
      <span style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 26 }}>{v}</span>
      <span style={{ fontSize: 9, color: C.muted, fontFamily: FONTS.mono }}>/ 100</span>
    </div></div>;
}
function PbBlock({ title, color, items, icon, numbered }) {
  return <div style={{ marginBottom: 16 }}>
    <div style={{ fontWeight: 700, fontSize: 13, color, marginBottom: 8 }}>{title}</div>
    {(items || []).map((it, i) => <div key={i} style={{ display: "flex", gap: 9, marginBottom: 7, fontSize: 13.5, lineHeight: 1.5 }}>
      <span style={{ color, flexShrink: 0, fontFamily: numbered ? FONTS.mono : "inherit", minWidth: numbered ? 16 : "auto" }}>{numbered ? (i + 1) + "." : icon}</span>
      <span style={{ color: C.text }}>{it}</span>
    </div>)}
  </div>;
}
function CvSection({ title, children }) {
  return <div style={{ marginTop: 14 }}>
    <div style={{ fontSize: 11, fontWeight: 700, color: "#14213d", textTransform: "uppercase", letterSpacing: 1, borderBottom: "1px solid #c9ad6a", paddingBottom: 3, marginBottom: 7 }}>{title}</div>
    {children}
  </div>;
}
function Dots() {
  return <div style={{ display: "flex", gap: 6, color: C.amber }}>
    <span className="cw-dot" style={{ fontSize: 22 }}>•</span>
    <span className="cw-dot" style={{ fontSize: 22, animationDelay: ".2s" }}>•</span>
    <span className="cw-dot" style={{ fontSize: 22, animationDelay: ".4s" }}>•</span></div>;
}
function ErrorNote({ text }) {
  return <div style={{ background: "rgba(233,139,115,0.1)", border: `1px solid ${C.red}`, color: C.red, borderRadius: 10, padding: "10px 14px", fontSize: 13.5, margin: "10px 0" }}>{text}</div>;
}
const btnPrimary = { flex: 1, padding: "14px", borderRadius: 12, border: "none", cursor: "pointer", background: C.amber, color: C.ink, fontWeight: 700, fontSize: 15, fontFamily: FONTS.body };
const btnGhost = { padding: "14px 18px", borderRadius: 12, cursor: "pointer", background: "transparent", color: C.text, border: `1px solid ${C.border}`, fontWeight: 600, fontSize: 14.5, fontFamily: FONTS.body };
const inputStyle = { width: "100%", background: C.panel2, color: C.text, border: `1px solid ${C.border}`, borderRadius: 10, padding: "12px 14px", fontSize: 14.5, fontFamily: FONTS.body, outline: "none", boxSizing: "border-box" };

// ── App ──────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("home"); // home | report | cv | terms | interview | feedback
  const [cfg, setCfg] = useState({ role: "analysis", customRole: "", caseType: "likely", difficulty: "junior", language: "mix", mode: "trainer", persona: "analytical", fitMode: "round" });
  const [sessionPersona, setSessionPersona] = useState(null);
  const [companyCtx, setCompanyCtx] = useState({ name: "", text: "" });
  const [videoMode, setVideoMode] = useState(false);
  const videoElRef = useRef(null);
  const camStreamRef = useRef(null);
  const [openPlaybook, setOpenPlaybook] = useState(null);
  const [target, setTarget] = useState({ company: "", role: "", country: "Colombia", jobDesc: "", requirements: "" });
  const [cvFile, setCvFile] = useState(null); // {name, b64, mediaType}
  const [diag, setDiag] = useState(null);
  const [certs, setCerts] = useState(null);
  const [adaptedCv, setAdaptedCv] = useState(null);
  const [terms, setTerms] = useState(null);
  const [subLoading, setSubLoading] = useState(""); // "cv" | "terms"
  const [phase, setPhase] = useState(""); // loading label
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [plan, setPlan] = useState(null);
  const [planLoading, setPlanLoading] = useState(false);
  const [voiceOn, setVoiceOn] = useState(false); // interviewer speaks
  const [listening, setListening] = useState(false);
  const [voiceMsg, setVoiceMsg] = useState("");
  const scrollRef = useRef(null);
  const fileRef = useRef(null);
  const recogRef = useRef(null);
  const baseInputRef = useRef(""); // text already typed before dictation

  const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
  const speechLang = { es: "es-ES", en: "en-US", mix: "es-ES" }[cfg.language];

  // strip markdown so TTS reads cleanly
  function toSpeech(t) {
    return (t || "")
      .split("\n")
      .filter((l) => !l.trim().startsWith("|"))
      .join(" ")
      .replace(/\*\*/g, "")
      .replace(/[#>*_`]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function speak(text) {
    try {
      const synth = window.speechSynthesis;
      if (!synth) return;
      synth.cancel();
      const u = new SpeechSynthesisUtterance(toSpeech(text));
      u.lang = speechLang;
      u.rate = 1.02;
      synth.speak(u);
    } catch (_) {}
  }
  function stopSpeaking() { try { window.speechSynthesis?.cancel(); } catch (_) {} }

  useEffect(() => {
    if (videoMode && camStreamRef.current && videoElRef.current) {
      videoElRef.current.srcObject = camStreamRef.current;
    }
  }, [videoMode, messages, loading]);

  async function enterVideo() {
    setVideoMsg(""); setVoiceOn(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      camStreamRef.current = stream;
      setVideoMode(true);
    } catch (e) {
      setVideoMsg("No pude abrir la cámara/micrófono. En el celular suele estar bloqueado; funciona en Chrome de escritorio dando permiso.");
    }
  }
  function exitVideo() {
    try { camStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch (_) {}
    camStreamRef.current = null;
    setVideoMode(false);
    stopSpeaking();
    if (listening) recogRef.current?.stop();
  }

  function toggleMic() {
    if (!SR) { setVoiceMsg("Tu navegador no permite dictado por voz aquí. Funciona mejor en Chrome de escritorio o Safari."); return; }
    if (listening) { recogRef.current?.stop(); return; }
    setVoiceMsg("");
    const r = new SR();
    r.lang = speechLang;
    r.continuous = true;
    r.interimResults = true;
    baseInputRef.current = input ? input + " " : "";
    r.onresult = (e) => {
      let txt = "";
      for (let i = 0; i < e.results.length; i++) txt += e.results[i][0].transcript;
      setInput(baseInputRef.current + txt);
    };
    r.onerror = (e) => {
      setListening(false);
      setVoiceMsg(e.error === "not-allowed" ? "Micrófono bloqueado. Ábrelo en un navegador de verdad (Chrome/Safari) y da permiso." : "No pude escuchar (" + e.error + ").");
    };
    r.onend = () => setListening(false);
    recogRef.current = r;
    try { r.start(); setListening(true); } catch (_) { setListening(false); }
  }

  useEffect(() => {
    const link = document.createElement("link"); link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,800&family=Hanken+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap";
    document.head.appendChild(link);
    const st = document.createElement("style");
    st.textContent = `@keyframes cwFade{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}@keyframes cwBlink{0%,100%{opacity:.25}50%{opacity:1}}.cw-dot{animation:cwBlink 1.1s infinite}.cw-fade{animation:cwFade .4s ease both}::-webkit-scrollbar{width:9px;height:9px}::-webkit-scrollbar-thumb{background:#2a323f;border-radius:6px}::-webkit-scrollbar-track{background:transparent}`;
    document.head.appendChild(st);
  }, []);
  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, loading]);

  const roleLabel = cfg.role === "custom"
    ? (cfg.customRole?.trim() || "el rol indicado")
    : (ROLES.find((r) => r.id === cfg.role)?.label || "Análisis de negocio / datos");

  // Parse the first markdown table into rows (array of arrays). Returns null if too small.
  function tableToRows(text) {
    const lines = (text || "").split("\n");
    const tbl = []; let started = false;
    for (const l of lines) {
      if (l.trim().startsWith("|")) { tbl.push(l); started = true; }
      else if (started) break; // only the first table
    }
    if (tbl.length < 2) return null;
    const rows = tbl
      .map((r) => r.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim()))
      .filter((r) => !r.every((c) => /^:?-+:?$/.test(c) || c === ""));
    return rows.length < 4 ? null : rows;
  }
  // Convert a cell to a real number when possible (handles "$48.500.000", "COP 1.200", "USD 1,200")
  function parseCell(v) {
    let s = (v || "").replace(/\*\*/g, "").trim();
    if (s === "" || s === "—" || s === "-") return "";
    const isMoney = /\$|cop|usd/i.test(s);
    const cleaned = s.replace(/\$|cop|usd/gi, "").trim();   // strip currency markers
    if (/^\d{1,3}(\.\d{3})+$/.test(cleaned)) return Number(cleaned.replace(/\./g, ""));   // 48.500.000 -> 48500000
    if (/^\d{1,3}(,\d{3})+$/.test(cleaned)) return Number(cleaned.replace(/,/g, ""));      // 1,200,000 -> 1200000
    if (/^-?\d+$/.test(cleaned)) return Number(cleaned);                                   // plain integer
    if (/^-?\d+[.,]\d+$/.test(cleaned)) return Number(cleaned.replace(",", "."));          // decimal
    return isMoney ? s : s;                                                                // leave as-is otherwise
  }
  // Pull the scenario description and the numbered tasks out of the interviewer message
  function extractExcelParts(content) {
    const rows = tableToRows(content);
    if (!rows) return null;
    const lines = (content || "").split("\n");
    const desc = [];
    for (const l of lines) { if (l.trim().startsWith("|")) break; if (l.trim()) desc.push(l.replace(/[*#]/g, "").trim()); }
    let afterTable = false; const tasks = [];
    for (const l of lines) {
      if (l.trim().startsWith("|")) { afterTable = true; continue; }
      if (afterTable) {
        const m = l.trim().replace(/\*\*/g, "");
        if (/^\d+[.)]/.test(m) || /^[-*]\s/.test(m)) tasks.push(m.replace(/^\d+[.)]\s*/, "").replace(/^[-*]\s*/, ""));
      }
    }
    return { rows, description: desc.join(" "), tasks };
  }
  function downloadXlsx(content) {
    try {
      const parts = extractExcelParts(content);
      if (!parts) return;
      const { rows, description, tasks } = parts;
      const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const ncols = Math.max(rows[0].length, 4);
      const bd = "1px solid #c9ad6a";
      const thNavy = `background:#14213d;color:#ffffff;font-weight:bold;border:${bd};padding:7px 10px;font-family:Calibri,Arial;font-size:11pt;text-align:left;`;
      const thAmber = `background:#e7b75f;color:#14213d;font-weight:bold;border:${bd};padding:7px 10px;font-family:Calibri,Arial;font-size:11pt;text-align:left;`;
      const tdT = `border:${bd};padding:5px 10px;font-family:Calibri,Arial;font-size:10.5pt;mso-number-format:'@';`;
      const tdN = `border:${bd};padding:5px 10px;font-family:Calibri,Arial;font-size:10.5pt;text-align:right;mso-number-format:'#,##0';`;
      const tdInput = `border:${bd};padding:5px 10px;font-family:Calibri,Arial;font-size:10.5pt;mso-number-format:'General';`;

      const headerRow = `<tr>${rows[0].map((h) => `<th style="${thNavy}">${esc(h)}</th>`).join("")}</tr>`;
      const dataRows = rows.slice(1).map((r, ri) => {
        const bg = ri % 2 ? "background:#faf8f2;" : "background:#ffffff;";
        return `<tr>${r.map((c) => { const p = parseCell(c); return typeof p === "number" ? `<td style="${tdN}${bg}">${p}</td>` : `<td style="${tdT}${bg}">${esc(p)}</td>`; }).join("")}</tr>`;
      }).join("");

      const taskList = tasks.length ? tasks : ["Las tareas están en el chat de la entrevista."];
      const taskHeader = `<tr><th style="${thAmber};text-align:center;">#</th><th style="${thAmber}">Pregunta / Tarea</th><th style="${thAmber}">Tu respuesta</th><th style="${thAmber}">Fórmula usada</th></tr>`;
      const taskRows = taskList.map((t, i) => `<tr><td style="${tdT};text-align:center;background:#ffffff;">${i + 1}</td><td style="${tdT};background:#ffffff;">${esc(t)}</td><td style="${tdInput};background:#fffdf7;">&nbsp;</td><td style="${tdInput};background:#fffdf7;">&nbsp;</td></tr>`).join("");

      const spacer = `<tr><td colspan="${ncols}" style="height:10px;border:none;"></td></tr>`;
      const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head>
<body><table style="border-collapse:collapse;">
  <tr><td colspan="${ncols}" style="background:#0d0f14;padding:14px 16px;font-size:24pt;font-weight:bold;font-family:Georgia,'Times New Roman',serif;color:#f5f3ee;border:none;">Case<span style="color:#e7b75f;">work</span></td></tr>
  <tr><td colspan="${ncols}" style="background:#14213d;color:#e7b75f;padding:6px 16px;font-size:10pt;font-family:Calibri,Arial;border:none;letter-spacing:1px;">PRUEBA PRÁCTICA DE EXCEL${target.role ? ` &middot; ${esc(target.role)}` : ""}</td></tr>
  ${spacer}
  <tr><td colspan="${ncols}" style="font-weight:bold;color:#14213d;padding:3px 4px;font-family:Calibri,Arial;font-size:11pt;border:none;">Descripción de los datos</td></tr>
  <tr><td colspan="${ncols}" style="padding:3px 4px;font-family:Calibri,Arial;font-size:10.5pt;color:#333333;border:none;">${esc(description || "Conjunto de datos para resolver las tareas de la prueba.")}</td></tr>
  ${spacer}
  ${headerRow}
  ${dataRows}
  ${spacer}${spacer}
  <tr><td colspan="${ncols}" style="font-weight:bold;color:#14213d;padding:3px 4px;font-family:Calibri,Arial;font-size:13pt;border:none;">Tareas — resuélvelas aquí</td></tr>
  <tr><td colspan="${ncols}" style="color:#9c7d3e;font-size:9.5pt;padding:2px 4px;font-family:Calibri,Arial;border:none;">Llena «Tu respuesta» y «Fórmula usada», copia esta tabla y pégala en el chat para recibir tu evaluación.</td></tr>
  ${taskHeader}
  ${taskRows}
  ${spacer}
  <tr><td colspan="${ncols}" style="color:#9c7d3e;font-size:9pt;padding:6px 4px;font-family:Calibri,Arial;border:none;">Generado por Casework</td></tr>
</table></body></html>`;
      const blob = new Blob(["\ufeff" + html], { type: "application/vnd.ms-excel" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = "casework-prueba-excel.xls";
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    } catch (_) {}
  }

  function onFile(e) {
    const f = e.target.files?.[0]; if (!f) return;
    if (f.type !== "application/pdf" && !f.type.startsWith("image/")) {
      setError("Sube la HdV en PDF o imagen (el formato .docx no se puede leer directo)."); return;
    }
    setError("");
    const reader = new FileReader();
    reader.onload = () => setCvFile({ name: f.name, b64: reader.result.split(",")[1], mediaType: f.type });
    reader.readAsDataURL(f);
  }

  function docBlock() {
    if (!cvFile) return null;
    return cvFile.mediaType === "application/pdf"
      ? { type: "document", source: { type: "base64", media_type: "application/pdf", data: cvFile.b64 } }
      : { type: "image", source: { type: "base64", media_type: cvFile.mediaType, data: cvFile.b64 } };
  }

  async function analyzeCV() {
    if (!cvFile) return;
    setError(""); setLoading(true); setScreen("report"); setDiag(null); setCerts(null); setAdaptedCv(null); setTerms(null);
    const db = docBlock();
    try {
      setPhase("Diagnosticando tu HdV…");
      const d = await callClaude({
        messages: [{ role: "user", content: [db, { type: "text", text: cvDiagnosticSystem(target, roleLabel) + "\n\nAnaliza esta hoja de vida. Responde SOLO con el JSON." }] }],
      });
      const dj = parseJSON(d); setDiag(dj);

      setPhase("Armando tu guía de certificaciones…");
      const c = await callClaude({
        messages: [{ role: "user", content: certSystem(target, roleLabel) + `\n\nPerfil: ${dj.summary}\nFortalezas: ${(dj.strengths || []).join("; ")}\nBrechas: ${(dj.gaps || []).join("; ")}\n\nResponde SOLO con el JSON.` }],
      });
      setCerts(parseJSON(c).certifications);
    } catch (e) {
      setError("No pude analizar la HdV → " + (e.message || e));
    } finally { setLoading(false); setPhase(""); }
  }

  async function genAdaptedCv() {
    if (!cvFile) return;
    setScreen("cv");
    if (adaptedCv) return;
    setSubLoading("cv"); setError("");
    try {
      const raw = await callClaude({
        maxTokens: 4000,
        messages: [{ role: "user", content: [docBlock(), { type: "text", text: cvAdaptSystem(target, roleLabel) + "\n\nResponde SOLO con el JSON." }] }],
      });
      setAdaptedCv(parseJSON(raw));
    } catch (e) { setError("No pude generar la HdV adaptada → " + (e.message || e)); }
    finally { setSubLoading(""); }
  }

  async function genTerms() {
    setScreen("terms");
    if (terms) return;
    setSubLoading("terms"); setError("");
    try {
      const raw = await callClaude({ task: "light", maxTokens: 1600, messages: [{ role: "user", content: termsSystem(target, roleLabel) + "\n\nResponde SOLO con el JSON." }] });
      const parsed = parseJSON(raw);
      if (!parsed.terms || !parsed.terms.length) throw new Error("la respuesta llegó incompleta");
      setTerms(parsed.terms.filter((t) => t && t.term));
    } catch (e) { setError("No pude generar los términos → " + (e.message || e) + ". Si estás en el celular, prueba en Chrome de escritorio."); }
    finally { setSubLoading(""); }
  }

  function downloadDoc(cv) {
    try {
      const esc = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const sec = (title, inner) => inner ? `<div class="sec"><div class="h2">${esc(title)}</div>${inner}</div>` : "";
      const exp = (cv.experience || []).map((e) => `
        <div class="job">
          <table class="row"><tr><td class="role">${esc(e.role)}</td><td class="dates">${esc(e.dates)}</td></tr></table>
          <div class="org">${esc(e.org)}</div>
          ${(e.bullets || []).length ? `<ul>${e.bullets.map((b) => `<li>${esc(b)}</li>`).join("")}</ul>` : ""}
        </div>`).join("");
      const edu = (cv.education || []).map((e) => `<div class="edu"><table class="row"><tr><td class="role">${esc(e.title)}</td><td class="dates">${esc(e.dates)}</td></tr></table><div class="org">${esc(e.org)}</div></div>`).join("");
      const skills = (cv.skills || []).length ? `<div class="skills">${(cv.skills || []).map(esc).join(" · ")}</div>` : "";
      const certs = (cv.certifications || []).length ? `<ul>${(cv.certifications || []).map((c) => `<li>${esc(c)}</li>`).join("")}</ul>` : "";
      const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word'><head><meta charset='utf-8'>
<style>
@page { size: A4; margin: 1.3cm 1.5cm; }
* { box-sizing: border-box; }
body { font-family: Calibri, Arial, sans-serif; font-size: 10pt; color: #222; line-height: 1.22; margin: 0; }
.name { font-size: 19pt; font-weight: bold; color: #14213d; margin: 0; }
.headline { font-size: 10.5pt; color: #555; margin: 1pt 0 3pt; }
.contact { font-size: 8.5pt; color: #666; margin-bottom: 7pt; }
.summary { font-size: 9.5pt; margin-bottom: 8pt; }
.sec { margin-bottom: 8pt; }
.h2 { font-size: 9.5pt; font-weight: bold; color: #14213d; text-transform: uppercase; letter-spacing: .6pt; border-bottom: .8pt solid #c9ad6a; padding-bottom: 1.5pt; margin-bottom: 4pt; }
.job, .edu { margin-bottom: 7pt; }
.row { width: 100%; border-collapse: collapse; margin: 0; }
.row td { padding: 0; vertical-align: bottom; }
.role { font-weight: bold; font-size: 10pt; }
td.dates { font-size: 8.5pt; color: #777; font-style: italic; text-align: right; white-space: nowrap; width: 30%; }
.org { font-size: 9pt; color: #444; margin: 1pt 0 2pt; }
ul { margin: 2pt 0 0; padding-left: 15pt; }
li { font-size: 9.3pt; margin-bottom: 1.5pt; }
.skills { font-size: 9.3pt; }
</style></head><body>
<div class="name">${esc(cv.name)}</div>
${cv.headline ? `<div class="headline">${esc(cv.headline)}</div>` : ""}
${cv.contact ? `<div class="contact">${esc(cv.contact)}</div>` : ""}
${cv.summary ? `<div class="summary">${esc(cv.summary)}</div>` : ""}
${sec("Experiencia", exp)}
${sec("Educación", edu)}
${sec("Habilidades", skills)}
${sec("Certificaciones", certs)}
</body></html>`;
      const blob = new Blob(["\ufeff" + html], { type: "application/msword" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = "hdv-adaptada.doc";
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    } catch (_) {}
  }

  async function startCase() {
    setError(""); setLoading(true); setScreen("interview"); setMessages([]);
    try {
      // Research the company for real context (cached per company name)
      let ctxText = "";
      if (target.company && target.company.trim()) {
        if (companyCtx.name === target.company.trim() && companyCtx.text) {
          ctxText = companyCtx.text;
        } else {
          try {
            setPhase("Investigando la empresa…");
            ctxText = await callClaude({
              task: "light",
              maxTokens: 1200,
              tools: [{ type: "web_search_20250305", name: "web_search" }],
              messages: [{ role: "user", content: `Investiga la empresa "${target.company}" ${target.country ? `(en ${target.country})` : ""}. Resume en español, en 5-7 frases: a qué se dedica, sector, tamaño aproximado, productos/servicios, y proyectos o noticias reales recientes si los encuentras. Si es una empresa pequeña o local, enfócate en lo que realmente hace. Solo el resumen, sin preámbulo.` }],
            });
            setCompanyCtx({ name: target.company.trim(), text: ctxText });
          } catch (_) { ctxText = ""; } // research is best-effort; continue without it
        }
      }
      setPhase("");
      const pool = PERSONAS.filter((p) => p.id !== "random");
      const persona = cfg.persona === "random" ? pool[Math.floor(Math.random() * pool.length)].id : cfg.persona;
      setSessionPersona(persona);
      const sys = interviewSystem({ ...cfg, persona }, roleLabel, target, diag || null, ctxText);
      const seed = [{ role: "user", content: sys + "\n\nAhora empieza la entrevista. Responde como el entrevistador (NO en JSON)." }];
      const reply = await callClaude({ messages: seed });
      setMessages([...seed, { role: "assistant", content: reply }]);
      if (voiceOn) speak(reply);
    } catch (e) { setError("No pude generar el caso → " + (e.message || e)); }
    finally { setLoading(false); setPhase(""); }
  }
  async function send() {
    const txt = input.trim(); if (!txt || loading) return;
    if (listening) recogRef.current?.stop();
    stopSpeaking();
    const next = [...messages, { role: "user", content: txt }];
    setMessages(next); setInput(""); setLoading(true); setError("");
    try {
      const reply = await callClaude({ messages: next });
      setMessages([...next, { role: "assistant", content: reply }]);
      if (voiceOn) speak(reply);
    } catch (e) { setError("Error → " + (e.message || e) + " (reenvía)"); setMessages(next); }
    finally { setLoading(false); }
  }
  async function evaluate() {
    setLoading(true); setError(""); setScreen("feedback"); setPlan(null);
    try {
      const tr = messages.slice(1).map((m) => `${m.role === "user" ? "CANDIDATO" : "ENTREVISTADOR"}: ${m.content}`).join("\n\n");
      const raw = await callClaude({ messages: [{ role: "user", content: evalSystem(cfg) + "\n\nTranscripción:\n\n" + tr }] });
      setFeedback(parseJSON(raw));
    } catch (e) { setError("No pude generar el feedback → " + (e.message || e)); }
    finally { setLoading(false); }
  }
  async function genPlan() {
    if (!feedback || planLoading) return;
    setPlanLoading(true); setError("");
    try {
      const weak = (feedback.dimensions || []).filter((d) => d.score <= 3).map((d) => `${d.name} (${d.score}/5): ${d.comment}`).join("; ");
      const imp = (feedback.improvements || []).join("; ");
      const raw = await callClaude({ messages: [{ role: "user", content: planSystem(cfg) + `\n\nÁreas más débiles: ${weak || "usa las dimensiones de menor puntaje"}\nMejoras sugeridas: ${imp}\n\nResponde SOLO con el JSON.` }] });
      setPlan(parseJSON(raw));
    } catch (e) { setError("No pude generar el plan → " + (e.message || e)); }
    finally { setPlanLoading(false); }
  }
  function reset() { stopSpeaking(); if (listening) recogRef.current?.stop(); try { camStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch (_) {} camStreamRef.current = null; setVideoMode(false); setScreen("home"); setMessages([]); setFeedback(null); setPlan(null); setAdaptedCv(null); setTerms(null); setInput(""); setError(""); setVoiceMsg(""); }

  const wrap = { minHeight: "100vh", background: `radial-gradient(1200px 600px at 80% -10%, rgba(231,183,95,0.06), transparent), ${C.ink}`, color: C.text, fontFamily: FONTS.body };

  // ── HOME ───────────────────────────────────────────────────
  if (screen === "home") {
    return <div style={wrap}><div style={{ maxWidth: 760, margin: "0 auto", padding: "44px 22px 60px" }}>
      <div className="cw-fade" style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 8 }}>PREPARACIÓN PERSONALIZADA · IA</div>
        <h1 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 50, lineHeight: 1, margin: 0, letterSpacing: -1 }}>Case<span style={{ color: C.amber }}>work</span> <span style={{ fontSize: 22, color: C.muted, fontFamily: FONTS.mono, letterSpacing: 2 }}>PRO</span></h1>
        <p style={{ color: C.muted, fontSize: 15.5, marginTop: 12, maxWidth: 540, lineHeight: 1.55 }}>Sube tu HdV, dime para qué empresa te preparas, y la IA diagnostica tu perfil, te arma una ruta de certificaciones y genera una entrevista aterrizada en tu experiencia real.</p>
      </div>

      <Section title="01 · ¿Para qué empresa y cargo te preparas?">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <input style={inputStyle} placeholder="Empresa (ej. adidas, Bayer)" value={target.company} onChange={(e) => setTarget({ ...target, company: e.target.value })} />
          <input style={inputStyle} placeholder="Cargo (ej. Product Supply Specialist)" value={target.role} onChange={(e) => setTarget({ ...target, role: e.target.value })} />
        </div>
        <input style={{ ...inputStyle, marginTop: 10 }} placeholder="País del caso (ej. Colombia)" value={target.country} onChange={(e) => setTarget({ ...target, country: e.target.value })} />
        <textarea style={{ ...inputStyle, marginTop: 10, minHeight: 90, resize: "vertical", lineHeight: 1.5 }} placeholder="Descripción de la vacante — pega aquí el texto del aviso/oferta (recomendado). Se usa para adaptar tu HdV, la entrevista y los términos clave." value={target.jobDesc} onChange={(e) => setTarget({ ...target, jobDesc: e.target.value })} />
        <textarea style={{ ...inputStyle, marginTop: 10, minHeight: 64, resize: "vertical", lineHeight: 1.5 }} placeholder="Requisitos del cargo (opcional) — lista los requisitos clave y te diré, según tu HdV, qué tan apto eres y qué reforzar." value={target.requirements} onChange={(e) => setTarget({ ...target, requirements: e.target.value })} />
      </Section>

      <Section title="02 · Familia del rol (para el tipo de caso)">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: 10 }}>
          {ROLES.map((r) => <Choice key={r.id} active={cfg.role === r.id} label={r.label} desc={r.desc} onClick={() => setCfg({ ...cfg, role: r.id })} />)}
        </div>
        {cfg.role === "custom" && <input autoFocus style={{ ...inputStyle, marginTop: 10 }} placeholder="Escribe el área/rol (ej. Recursos Humanos, Analista de Compras)" value={cfg.customRole} onChange={(e) => setCfg({ ...cfg, customRole: e.target.value })} />}
      </Section>

      <Section title="03 · Tu hoja de vida (opcional, recomendado)">
        <input ref={fileRef} type="file" accept="application/pdf,image/*" onChange={onFile} style={{ display: "none" }} />
        <div onClick={() => fileRef.current?.click()} style={{ cursor: "pointer", border: `1.5px dashed ${cvFile ? C.amber : C.border}`, borderRadius: 12, padding: "22px", textAlign: "center", background: cvFile ? "rgba(231,183,95,0.06)" : "transparent", transition: "all .18s" }}>
          {cvFile ? <div><div style={{ color: C.amber, fontWeight: 600, fontSize: 14.5 }}>✓ {cvFile.name}</div><div style={{ color: C.muted, fontSize: 12.5, marginTop: 4 }}>Toca para cambiar</div></div>
            : <div><div style={{ fontWeight: 600, fontSize: 14.5 }}>↑ Sube tu HdV (PDF o imagen)</div><div style={{ color: C.muted, fontSize: 12.5, marginTop: 4 }}>La IA la lee y te dice qué te falta</div></div>}
        </div>
        {cvFile && <button onClick={(e) => { e.stopPropagation(); setCvFile(null); setDiag(null); setCerts(null); setAdaptedCv(null); setTerms(null); if (fileRef.current) fileRef.current.value = ""; }}
          style={{ marginTop: 10, padding: "9px 14px", borderRadius: 10, border: `1px solid ${C.border}`, background: "transparent", color: C.red, fontWeight: 600, fontSize: 13, fontFamily: FONTS.body, cursor: "pointer" }}>
          ✕ Quitar HdV
        </button>}
      </Section>

      <Section title="04 · Configuración del caso">
        <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 14, lineHeight: 1.5 }}>Elige cómo quieres practicar. Si no sabes por dónde empezar, deja <strong style={{ color: C.text }}>Trainer</strong> + <strong style={{ color: C.text }}>Lo más probable</strong> + <strong style={{ color: C.text }}>Junior</strong>.</div>

        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Modo</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          {MODES.map((m) => <Choice key={m.id} active={cfg.mode === m.id} label={m.label} desc={m.desc} onClick={() => setCfg({ ...cfg, mode: m.id })} />)}
        </div>

        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Entrevistador</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 10, marginBottom: 16 }}>
          {PERSONAS.map((p) => <Choice key={p.id} active={cfg.persona === p.id} label={p.label} desc={p.desc} onClick={() => setCfg({ ...cfg, persona: p.id })} />)}
        </div>

        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Tipo de caso</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 10, marginBottom: 10 }}>
          {CASE_TYPES.map((t) => <Choice key={t.id} active={cfg.caseType === t.id} label={t.label} desc={t.desc} onClick={() => setCfg({ ...cfg, caseType: t.id })} />)}
        </div>
        {(() => {
          const hasPb = PLAYBOOKS.some((p) => p.id === cfg.caseType);
          const lbl = hasPb ? `📘 Ver playbook: ${PLAYBOOKS.find((p) => p.id === cfg.caseType).title}` : "📘 Ver playbooks Casework";
          return <button onClick={() => { setOpenPlaybook(hasPb ? cfg.caseType : null); setScreen("playbooks"); }} style={{ ...btnGhost, padding: "9px 14px", fontSize: 13, color: C.amber, borderColor: C.amberDim, marginBottom: 16 }}>{lbl}</button>;
        })()}
        {cfg.caseType === "fit" && <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Formato del fit</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {FIT_MODES.map((f) => <Choice key={f.id} active={cfg.fitMode === f.id} label={f.label} desc={f.desc} onClick={() => setCfg({ ...cfg, fitMode: f.id })} />)}
          </div>
        </div>}

        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Nivel del candidato</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
          {DIFFS.map((d) => <Pill key={d.id} active={cfg.difficulty === d.id} onClick={() => setCfg({ ...cfg, difficulty: d.id })}>{d.label}</Pill>)}
        </div>

        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>Idioma</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {LANGS.map((l) => <Pill key={l.id} active={cfg.language === l.id} onClick={() => setCfg({ ...cfg, language: l.id })}>{l.label}</Pill>)}
        </div>
      </Section>

      {error && <ErrorNote text={error} />}
      <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
        {cvFile
          ? <button onClick={analyzeCV} style={btnPrimary}>Analizar HdV y preparar →</button>
          : <button onClick={startCase} style={btnPrimary}>Empezar entrevista →</button>}
        {cvFile && <button onClick={startCase} style={btnGhost}>Saltar al caso</button>}
      </div>
    </div></div>;
  }

  // ── REPORT (CV diagnostic + certs) ─────────────────────────
  if (screen === "report") {
    return <div style={wrap}><div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 22px 60px" }}>
      <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 6 }}>
        DIAGNÓSTICO DE PERFIL {target.company ? `· ${target.company.toUpperCase()}` : ""}
      </div>
      <h2 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, margin: "0 0 22px" }}>Tu HdV, según la IA</h2>

      {loading && <div style={{ display: "flex", gap: 10, alignItems: "center", color: C.muted, padding: "16px 0" }}><Dots />{phase}</div>}
      {error && <ErrorNote text={error} />}

      {diag && <div className="cw-fade">
        <div style={{ display: "flex", gap: 16, alignItems: "center", background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: 18, marginBottom: 16 }}>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 18, color: C.amber, border: `1px solid ${C.amberDim}`, borderRadius: 8, padding: "6px 14px", whiteSpace: "nowrap" }}>{diag.level}</div>
          <div style={{ fontSize: 14.5, color: C.text, lineHeight: 1.5 }}>{diag.summary}</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 12, marginBottom: 16 }}>
          {diag.readiness && <div style={{ background: C.panel, border: `1px solid ${diag.readiness.label === "Apto" ? C.green : diag.readiness.label === "Aún en desarrollo" ? C.amber : C.blue}`, borderRadius: 14, padding: "16px 18px" }}>
            <div style={{ fontFamily: FONTS.mono, fontSize: 10.5, letterSpacing: 1.5, color: C.muted, marginBottom: 6 }}>¿APTO PARA EL CARGO?</div>
            <div style={{ fontFamily: FONTS.display, fontSize: 20, color: diag.readiness.label === "Apto" ? C.green : diag.readiness.label === "Aún en desarrollo" ? C.amber : C.blue, marginBottom: 6 }}>{diag.readiness.label}</div>
            {diag.readiness.note && <div style={{ fontSize: 13.5, color: C.text, marginBottom: 10, lineHeight: 1.5 }}>{diag.readiness.note}</div>}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {diag.readiness.meets?.length > 0 && <div><div style={{ fontSize: 12, fontWeight: 600, color: C.green, marginBottom: 4 }}>Cumples</div>{diag.readiness.meets.map((m, i) => <div key={i} style={{ fontSize: 12.5, color: C.muted, marginBottom: 3 }}>✓ {m}</div>)}</div>}
              {diag.readiness.toClose?.length > 0 && <div><div style={{ fontSize: 12, fontWeight: 600, color: C.amber, marginBottom: 4 }}>Por reforzar</div>{diag.readiness.toClose.map((m, i) => <div key={i} style={{ fontSize: 12.5, color: C.muted, marginBottom: 3 }}>↗ {m}</div>)}</div>}
            </div>
          </div>}
          {diag.experience?.length > 0 && <Card title="Experiencia que el entrevistador usará" color={C.blue} icon="•" items={diag.experience} />}
          <Card title="Fortalezas" color={C.green} icon="✓" items={diag.strengths} />
          <Card title="A reforzar para este rol" color={C.amber} icon="↗" items={diag.gaps} />
          <Card title="Mejoras al documento" color={C.amber} icon="→" items={diag.cvFixes} />
          {diag.matchRoles?.length > 0 && <Card title="Tu perfil también hace match con" color={C.blue} icon="◆" items={diag.matchRoles} />}
        </div>
        {diag.fit && <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: "16px 18px", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 12 }}>
            <ScoreRing value={diag.fit.score} />
            <div>
              <div style={{ fontWeight: 700, fontSize: 14.5, color: C.text }}>Ajuste a la vacante</div>
              <div style={{ fontSize: 12.5, color: C.muted, marginTop: 2 }}>{target.jobDesc ? "Comparado con la descripción que pegaste" : "Estimado según el cargo y la empresa"}</div>
            </div>
          </div>
          {diag.fit.matches?.length > 0 && <Card title="Lo que SÍ encaja" color={C.green} icon="✓" items={diag.fit.matches} />}
          {diag.fit.missing?.length > 0 && <div style={{ marginTop: 10 }}><Card title="Lo que la vacante pide y no aparece" color={C.red} icon="!" items={diag.fit.missing} /></div>}
        </div>}
      </div>}

      {certs && <div className="cw-fade" style={{ marginBottom: 8 }}>
        <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 2, color: C.amber, marginBottom: 11 }}>RUTA DE CERTIFICACIONES</div>
        {certs.map((ct, i) => {
          const pc = ct.priority === "Alta" ? C.red : ct.priority === "Media" ? C.amber : C.muted;
          return <div key={i} style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 12, padding: "13px 16px", marginBottom: 9 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 10 }}>
              <span style={{ fontWeight: 600, fontSize: 14.5 }}>{ct.name}</span>
              <span style={{ fontSize: 11, fontFamily: FONTS.mono, color: pc, border: `1px solid ${pc}`, borderRadius: 6, padding: "2px 7px", whiteSpace: "nowrap" }}>{ct.priority}</span>
            </div>
            <div style={{ fontSize: 12.5, color: C.muted, marginTop: 3 }}>{ct.provider}</div>
            <div style={{ fontSize: 13.5, color: C.text, marginTop: 6, lineHeight: 1.5 }}>{ct.why}</div>
          </div>;
        })}
      </div>}

      {diag && !loading && <div className="cw-fade" style={{ marginTop: 22 }}>
        <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 2, color: C.amber, marginBottom: 11 }}>¿QUÉ QUIERES HACER?</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 10 }}>
          <button onClick={startCase} style={{ ...btnGhost, textAlign: "left", borderColor: C.amber, color: C.amber, padding: "15px 18px" }}>
            🎯 Ir a la simulación de entrevista
            <div style={{ fontSize: 12.5, color: C.muted, fontWeight: 400, marginTop: 3 }}>Caso aterrizado en tu HdV, el cargo y la vacante</div>
          </button>
          <button onClick={genAdaptedCv} style={{ ...btnGhost, textAlign: "left", padding: "15px 18px" }}>
            📄 Ver mi HdV adaptada al rol
            <div style={{ fontSize: 12.5, color: C.muted, fontWeight: 400, marginTop: 3 }}>Tu misma información, reorganizada para la vacante — sin inventar nada</div>
          </button>
          <button onClick={genTerms} style={{ ...btnGhost, textAlign: "left", padding: "15px 18px" }}>
            📚 Términos importantes de la vacante
            <div style={{ fontSize: 12.5, color: C.muted, fontWeight: 400, marginTop: 3 }}>Conceptos, herramientas y siglas que deberías dominar</div>
          </button>
        </div>
        <button onClick={reset} style={{ ...btnGhost, width: "100%", marginTop: 12, color: C.muted }}>Atrás</button>
      </div>}
    </div></div>;
  }

  // ── ADAPTED CV ─────────────────────────────────────────────
  if (screen === "cv") {
    return <div style={wrap}><div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 22px 60px" }}>
      <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 6 }}>HDV ADAPTADA {target.role ? `· ${target.role.toUpperCase()}` : ""}</div>
      <h2 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 30, margin: "0 0 8px" }}>Tu HdV, enfocada al rol</h2>
      <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 20, lineHeight: 1.5 }}>Solo tu información real, reorganizada y redactada para esta vacante. No se inventó experiencia, resúmenes ni certificaciones.</div>
      {subLoading === "cv" && <div style={{ display: "flex", gap: 10, alignItems: "center", color: C.muted, padding: "16px 0" }}><Dots />Adaptando tu HdV con tu información real…</div>}
      {error && <ErrorNote text={error} />}
      {adaptedCv && <div className="cw-fade" style={{ background: "#fbfaf7", color: "#222", border: `1px solid ${C.border}`, borderRadius: 14, padding: "26px 28px", boxShadow: "0 8px 30px rgba(0,0,0,0.35)" }}>
        <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 24, color: "#14213d", lineHeight: 1.1 }}>{adaptedCv.name}</div>
        {adaptedCv.headline && <div style={{ fontSize: 13.5, color: "#555", marginTop: 3 }}>{adaptedCv.headline}</div>}
        {adaptedCv.contact && <div style={{ fontSize: 11.5, color: "#777", marginTop: 4 }}>{adaptedCv.contact}</div>}
        {adaptedCv.summary && <div style={{ fontSize: 13, color: "#333", marginTop: 12, lineHeight: 1.45 }}>{adaptedCv.summary}</div>}

        {(adaptedCv.experience || []).length > 0 && <CvSection title="Experiencia">
          {adaptedCv.experience.map((e, i) => <div key={i} style={{ marginBottom: 11 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 16 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5, color: "#222", flex: 1 }}>{e.role}</span>
              {e.dates && <span style={{ fontSize: 11, color: "#888", fontStyle: "italic", whiteSpace: "nowrap", flexShrink: 0 }}>{e.dates}</span>}
            </div>
            <div style={{ fontSize: 12, color: "#555", marginTop: 1 }}>{e.org}</div>
            {(e.bullets || []).length > 0 && <ul style={{ margin: "4px 0 0", paddingLeft: 18 }}>{e.bullets.map((b, j) => <li key={j} style={{ fontSize: 12.5, color: "#333", marginBottom: 2, lineHeight: 1.4 }}>{b}</li>)}</ul>}
          </div>)}
        </CvSection>}

        {(adaptedCv.education || []).length > 0 && <CvSection title="Educación">
          {adaptedCv.education.map((e, i) => <div key={i} style={{ marginBottom: 7 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 16 }}>
              <span style={{ fontWeight: 700, fontSize: 13, color: "#222", flex: 1 }}>{e.title}</span>
              {e.dates && <span style={{ fontSize: 11, color: "#888", fontStyle: "italic", whiteSpace: "nowrap", flexShrink: 0 }}>{e.dates}</span>}
            </div>
            <div style={{ fontSize: 12, color: "#555", marginTop: 1 }}>{e.org}</div>
          </div>)}
        </CvSection>}

        {(adaptedCv.skills || []).length > 0 && <CvSection title="Habilidades">
          <div style={{ fontSize: 12.5, color: "#333" }}>{adaptedCv.skills.join("  ·  ")}</div>
        </CvSection>}

        {(adaptedCv.certifications || []).length > 0 && <CvSection title="Certificaciones">
          <ul style={{ margin: 0, paddingLeft: 18 }}>{adaptedCv.certifications.map((c, i) => <li key={i} style={{ fontSize: 12.5, color: "#333", marginBottom: 2 }}>{c}</li>)}</ul>
        </CvSection>}
      </div>}
      {adaptedCv && (adaptedCv.changes || []).length > 0 && <div className="cw-fade" style={{ marginTop: 14 }}>
        <Card title="Cambios que hice al adaptar (revísalos)" color={C.blue} icon="•" items={adaptedCv.changes} />
      </div>}
      <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
        {adaptedCv && <button onClick={() => downloadDoc(adaptedCv)} style={btnPrimary}>⬇ Descargar Word (1 página)</button>}
        <button onClick={() => setScreen("report")} style={btnGhost}>Volver al menú</button>
      </div>
    </div></div>;
  }

  // ── IMPORTANT TERMS ────────────────────────────────────────
  if (screen === "terms") {
    return <div style={wrap}><div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 22px 60px" }}>
      <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 6 }}>TÉRMINOS CLAVE {target.role ? `· ${target.role.toUpperCase()}` : ""}</div>
      <h2 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 30, margin: "0 0 8px" }}>Lo que deberías dominar</h2>
      <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 20, lineHeight: 1.5 }}>Conceptos, herramientas y siglas que probablemente aparezcan en tu entrevista para esta vacante.</div>
      {subLoading === "terms" && <div style={{ display: "flex", gap: 10, alignItems: "center", color: C.muted, padding: "16px 0" }}><Dots />Reuniendo los términos clave…</div>}
      {error && <ErrorNote text={error} />}
      {terms && <div className="cw-fade">
        {terms.map((t, i) => <div key={i} style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 16px", marginBottom: 10 }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: C.amber, marginBottom: 5 }}>{t.term}</div>
          <div style={{ fontSize: 13.5, color: C.text, lineHeight: 1.5 }}>{t.definition}</div>
          {t.formula && t.formula.trim() && <div style={{ fontFamily: FONTS.mono, fontSize: 12.5, color: C.green, marginTop: 7, background: "rgba(116,199,154,0.08)", border: `1px solid ${C.border}`, borderRadius: 8, padding: "7px 10px" }}>ƒ {t.formula}</div>}
          {t.whyMatters && <div style={{ fontSize: 12.5, color: C.muted, marginTop: 6, borderLeft: `2px solid ${C.border}`, paddingLeft: 10 }}>Por qué importa: {t.whyMatters}</div>}
        </div>)}
      </div>}
      <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
        <button onClick={() => setScreen("report")} style={btnPrimary}>Volver al menú</button>
      </div>
    </div></div>;
  }

  // ── PLAYBOOKS ──────────────────────────────────────────────
  if (screen === "playbooks") {
    const pb = PLAYBOOKS.find((p) => p.id === openPlaybook);
    const personaTip = cfg.persona === "random" ? "Con 🎲 Al azar no sabes quién te tocará — repasa los estilos antes de entrar." : PERSONA_TIPS[cfg.persona];
    return <div style={wrap}><div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 22px 60px" }}>
      <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 6 }}>PLAYBOOKS</div>
      <h2 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, margin: "0 0 4px" }}>
        Guías rápidas <span style={{ color: C.amber }}>Casework</span>
      </h2>
      <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18, lineHeight: 1.5 }}>Frameworks, pensamiento estructurado y errores comunes — sin respuestas hechas. Concisas a propósito.</div>

      {personaTip && <div style={{ background: "rgba(231,183,95,0.08)", border: `1px solid ${C.amberDim}`, borderRadius: 12, padding: "12px 15px", marginBottom: 18 }}>
        <span style={{ color: C.amber, fontWeight: 700, fontSize: 12.5 }}>Para tu entrevistador · </span>
        <span style={{ fontSize: 13, color: C.text }}>{personaTip}</span>
      </div>}

      {!pb && <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 10 }}>
        {PLAYBOOKS.map((p) => <button key={p.id} onClick={() => setOpenPlaybook(p.id)} style={{ ...btnGhost, textAlign: "left", padding: "15px 17px" }}>📘 {p.title}</button>)}
      </div>}

      {pb && <div className="cw-fade">
        <button onClick={() => setOpenPlaybook(null)} style={{ ...btnGhost, padding: "7px 13px", fontSize: 12.5, color: C.muted, marginBottom: 14 }}>← Todos los playbooks</button>
        <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: "20px 22px" }}>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 22, marginBottom: 4 }}>{pb.title}</div>
          <div style={{ fontFamily: FONTS.mono, fontSize: 10, letterSpacing: 2, color: C.amberDim, marginBottom: 16 }}>PLAYBOOK CASEWORK</div>

          <PbBlock title="Cómo estructurarlo" color={C.amber} items={pb.framework} numbered />
          <PbBlock title="Claves" color={C.green} items={pb.tips} icon="✓" />
          <PbBlock title="Errores comunes" color={C.red} items={pb.errors} icon="✕" />
        </div>
      </div>}

      <button onClick={reset} style={{ ...btnGhost, width: "100%", marginTop: 18, color: C.muted }}>Volver al inicio</button>
    </div></div>;
  }

  // ── FEEDBACK ───────────────────────────────────────────────
  if (screen === "feedback") {
    return <div style={wrap}><div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 22px 60px" }}>
      <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 3, color: C.amberDim, marginBottom: 6 }}>EVALUACIÓN · {(target.role || roleLabel).toUpperCase()}</div>
      <h2 style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 34, margin: "0 0 24px" }}>Tu desempeño</h2>
      {loading && <div style={{ display: "flex", gap: 10, alignItems: "center", color: C.muted, padding: "12px 0" }}><Dots />Evaluando tu razonamiento…</div>}
      {error && <ErrorNote text={error} />}
      {feedback && !loading && <div className="cw-fade">
        <div style={{ display: "flex", gap: 22, alignItems: "center", background: C.panel, border: `1px solid ${C.border}`, borderRadius: 16, padding: 22, marginBottom: 20 }}>
          <ScoreRing value={feedback.overall} />
          <div><div style={{ fontSize: 12, color: C.muted, marginBottom: 4, fontFamily: FONTS.mono, letterSpacing: 1 }}>VEREDICTO</div>
            <div style={{ fontFamily: FONTS.display, fontSize: 19, lineHeight: 1.35 }}>{feedback.verdict}</div></div>
        </div>
        <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 16, padding: "8px 20px 16px", marginBottom: 20 }}>
          {feedback.dimensions?.map((d, i) => <div key={i} style={{ padding: "13px 0", borderBottom: i < feedback.dimensions.length - 1 ? `1px solid ${C.border}` : "none" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
              <span style={{ fontWeight: 600, fontSize: 14.5 }}>{d.name}</span>
              <span style={{ fontFamily: FONTS.mono, fontSize: 13, color: C.amber }}>{d.score}/5</span></div>
            <div style={{ height: 6, background: C.panel2, borderRadius: 4, overflow: "hidden", marginBottom: 7 }}><div style={{ width: `${(d.score / 5) * 100}%`, height: "100%", background: C.amber, borderRadius: 4 }} /></div>
            <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.5 }}>{d.comment}</div></div>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 14 }}>
          <Card title="Lo que hiciste bien" color={C.green} icon="✓" items={feedback.strengths} />
          <Card title="Para pulir" color={C.amber} icon="→" items={feedback.improvements} />
        </div>

        {!plan && !planLoading && (
          <button onClick={genPlan} style={{ ...btnGhost, width: "100%", marginTop: 14, borderColor: C.amber, color: C.amber }}>
            Cómo practicar para pulir esto →
          </button>
        )}
        {planLoading && <div style={{ display: "flex", gap: 10, alignItems: "center", color: C.muted, padding: "16px 2px" }}><Dots />Diseñando tu plan de práctica…</div>}
        {plan && <div className="cw-fade" style={{ marginTop: 18 }}>
          <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 2, color: C.amber, marginBottom: 11 }}>PLAN DE PRÁCTICA</div>
          {(plan.plan || []).map((p, i) => (
            <div key={i} style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 16px", marginBottom: 10 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5, color: C.amber, marginBottom: 6 }}>{p.area}</div>
              <div style={{ fontSize: 13.5, color: C.text, lineHeight: 1.5 }}><strong style={{ color: C.text }}>Ejercicio: </strong>{p.drill}</div>
              {p.example && <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.5, marginTop: 6, borderLeft: `2px solid ${C.border}`, paddingLeft: 10 }}>{p.example}</div>}
            </div>
          ))}
          {plan.habit && <div style={{ background: "rgba(116,199,154,0.08)", border: `1px solid ${C.green}`, borderRadius: 12, padding: "13px 16px", marginTop: 4 }}>
            <span style={{ color: C.green, fontWeight: 700, fontSize: 13.5 }}>Hábito semanal · </span>
            <span style={{ fontSize: 13.5, color: C.text }}>{plan.habit}</span>
          </div>}
        </div>}
      </div>}
      <div style={{ display: "flex", gap: 10, marginTop: 26 }}>
        <button onClick={reset} style={btnPrimary}>Otra ronda</button>
        <button onClick={() => setScreen("interview")} style={btnGhost}>Ver transcripción</button>
      </div>
    </div></div>;
  }

  // ── INTERVIEW ──────────────────────────────────────────────
  return <div style={{ ...wrap, display: "flex", flexDirection: "column", height: "100vh" }}>
    <div style={{ borderBottom: `1px solid ${C.border}`, padding: "13px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "rgba(13,15,20,0.85)", backdropFilter: "blur(8px)" }}>
      <div>
        <span style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 19 }}>Case<span style={{ color: C.amber }}>work</span></span>
        <span style={{ fontFamily: FONTS.mono, fontSize: 11, color: C.muted, marginLeft: 12 }}>{target.company || roleLabel} · {DIFFS.find((d) => d.id === cfg.difficulty)?.label}{sessionPersona ? ` · ${PERSONAS.find((p) => p.id === sessionPersona)?.label}` : ""}</span>
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <button onClick={() => (videoMode ? exitVideo() : enterVideo())} title="Entrevista en video"
          style={{ ...btnGhost, padding: "8px 12px", fontSize: 13, color: videoMode ? C.amber : C.muted, borderColor: videoMode ? C.amber : C.border }}>
          🎥
        </button>
        <button onClick={() => { const v = !voiceOn; setVoiceOn(v); if (!v) stopSpeaking(); }} title="El entrevistador habla"
          style={{ ...btnGhost, padding: "8px 12px", fontSize: 15, color: voiceOn ? C.amber : C.muted, borderColor: voiceOn ? C.amber : C.border }}>
          {voiceOn ? "🔊" : "🔈"}
        </button>
        {messages.length > 2 && <button onClick={evaluate} style={{ ...btnGhost, padding: "8px 14px", fontSize: 13 }}>Terminar · feedback</button>}
        <button onClick={reset} style={{ ...btnGhost, padding: "8px 14px", fontSize: 13, color: C.muted }}>Salir</button>
      </div>
    </div>
    <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "24px 0" }}>
      <div style={{ maxWidth: 720, margin: "0 auto", padding: "0 20px" }}>
        {messages.slice(1).map((m, i) => {
          const rows = m.role === "assistant" ? tableToRows(m.content) : null;
          return <div key={i} className="cw-fade" style={{ marginBottom: 20, display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{ maxWidth: m.role === "user" ? "80%" : "100%", background: m.role === "user" ? C.amber : C.panel, color: m.role === "user" ? C.ink : C.text, border: m.role === "user" ? "none" : `1px solid ${C.border}`, borderRadius: 14, padding: m.role === "user" ? "12px 16px" : "16px 18px", fontSize: 14.5 }}>
              {m.role === "assistant" && <div style={{ fontFamily: FONTS.mono, fontSize: 10.5, letterSpacing: 2, color: C.amberDim, marginBottom: 8 }}>ENTREVISTADOR</div>}
              {m.role === "user" ? <span style={{ lineHeight: 1.55 }}>{m.content}</span> : <Markdown text={m.content} />}
              {rows && <button onClick={() => downloadXlsx(m.content)} style={{ marginTop: 10, padding: "9px 14px", borderRadius: 10, border: `1px solid ${C.amber}`, background: "rgba(231,183,95,0.10)", color: C.amber, fontWeight: 600, fontSize: 13, fontFamily: FONTS.body, cursor: "pointer" }}>⬇ Descargar Excel con la prueba</button>}
            </div></div>;
        })}
        {loading && <div style={{ padding: "6px 4px", display: "flex", gap: 10, alignItems: "center", color: C.muted }}><Dots />{phase}</div>}
        {error && <ErrorNote text={error} />}
      </div>
    </div>
    <div style={{ borderTop: `1px solid ${C.border}`, padding: "14px 20px", background: C.ink }}>
      <div style={{ maxWidth: 720, margin: "0 auto" }}>
        {voiceMsg && <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 8 }}>{voiceMsg}</div>}
        {videoMode ? <div>
          <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 12 }}>
            <video ref={videoElRef} autoPlay muted playsInline style={{ width: 150, height: 100, borderRadius: 12, objectFit: "cover", background: "#000", border: `1px solid ${C.border}`, transform: "scaleX(-1)" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: FONTS.mono, fontSize: 10.5, letterSpacing: 1.5, color: listening ? C.red : C.amberDim }}>{listening ? "● GRABANDO TU RESPUESTA" : "EN VIVO · responde hablando"}</div>
              <div style={{ fontSize: 13, color: C.muted, marginTop: 4, minHeight: 18 }}>{input || "Toca el micrófono y habla; luego envía tu respuesta."}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={toggleMic} style={{ flex: 1, padding: "14px", borderRadius: 12, border: `1px solid ${listening ? C.red : C.border}`, cursor: "pointer", background: listening ? "rgba(233,139,115,0.14)" : C.panel, color: listening ? C.red : C.text, fontWeight: 700, fontSize: 14.5, fontFamily: FONTS.body }}>
              <span className={listening ? "cw-dot" : ""}>🎙️</span> {listening ? "Detener" : "Hablar"}
            </button>
            <button onClick={send} disabled={loading || !input.trim()} style={{ flex: 1, padding: "14px", borderRadius: 12, border: "none", cursor: loading || !input.trim() ? "default" : "pointer", background: loading || !input.trim() ? C.border : C.amber, color: loading || !input.trim() ? C.muted : C.ink, fontWeight: 700, fontSize: 14.5, fontFamily: FONTS.body }}>Enviar respuesta</button>
          </div>
        </div> : <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
          <button onClick={toggleMic} title="Responder por voz"
            style={{ padding: "13px 15px", borderRadius: 12, border: `1px solid ${listening ? C.red : C.border}`, cursor: "pointer", background: listening ? "rgba(233,139,115,0.12)" : C.panel, color: listening ? C.red : C.muted, fontSize: 17, flexShrink: 0 }}>
            <span className={listening ? "cw-dot" : ""}>🎙️</span>
          </button>
          <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder={listening ? "Escuchando… habla y luego envía" : "Piensa en voz alta… (Enter envía · Shift+Enter salto)"} rows={1}
            style={{ flex: 1, resize: "none", background: C.panel, color: C.text, border: `1px solid ${listening ? C.red : C.border}`, borderRadius: 12, padding: "13px 15px", fontSize: 14.5, fontFamily: FONTS.body, outline: "none", maxHeight: 140, lineHeight: 1.5 }} />
          <button onClick={send} disabled={loading || !input.trim()} style={{ padding: "13px 20px", borderRadius: 12, border: "none", cursor: loading || !input.trim() ? "default" : "pointer", background: loading || !input.trim() ? C.border : C.amber, color: loading || !input.trim() ? C.muted : C.ink, fontWeight: 700, fontSize: 14.5, fontFamily: FONTS.body }}>Enviar</button>
        </div>}
      </div>
    </div>
  </div>;
}
