// /api/claude — Backend proxy para la API de Anthropic.
// La API key vive AQUÍ (variable de entorno), nunca en el frontend.
//
// Enrutamiento de modelos (verifica los nombres vigentes en https://docs.claude.com):
//   task "light" → Haiku  (barato: términos, research de empresa)
//   task "deep"  → Sonnet (entrevista, feedback, HdV)

const MODELS = {
  light: process.env.MODEL_LIGHT || "claude-haiku-4-5-20251001",
  deep: process.env.MODEL_DEEP || "claude-sonnet-4-6",
};

// Límite básico por IP (en memoria; se reinicia con cada cold start).
// Para límites reales por usuario, usar Supabase (fase 2).
const hits = new Map();
const WINDOW_MS = 60 * 60 * 1000; // 1 hora
const MAX_PER_WINDOW = parseInt(process.env.MAX_CALLS_PER_HOUR || "60", 10);

function rateLimited(ip) {
  const now = Date.now();
  const rec = hits.get(ip) || { count: 0, start: now };
  if (now - rec.start > WINDOW_MS) { rec.count = 0; rec.start = now; }
  rec.count++;
  hits.set(ip, rec);
  return rec.count > MAX_PER_WINDOW;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  if (rateLimited(ip)) {
    return res.status(429).json({ error: "Límite de uso alcanzado. Intenta en un rato." });
  }

  const { messages, maxTokens = 1000, tools, task = "deep" } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "messages requerido" });
  }

  const body = {
    model: MODELS[task] || MODELS.deep,
    max_tokens: Math.min(maxTokens, 4096), // techo de seguridad
    messages,
  };
  if (tools) body.tools = tools;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    // Devolvemos el status real (el frontend ya maneja reintentos en 429/529/5xx)
    return res.status(r.status).json(data);
  } catch (e) {
    return res.status(502).json({ error: "Upstream error", detail: String(e).slice(0, 200) });
  }
}
