# Casework Pro — Guía de deploy (Vercel)

Esta carpeta es el proyecto **listo para desplegar**. El frontend es tu app tal cual
(con dos cambios: las llamadas de IA van a `/api/claude` y hay enrutamiento Haiku/Sonnet),
y el backend (`api/claude.js`) guarda tu API key y habla con Anthropic.

---

## Paso 0 — Lo que necesitas (una sola vez)

1. **Cuenta GitHub** (github.com) — para alojar el código.
2. **Cuenta Vercel** (vercel.com) — regístrate con tu GitHub. Plan gratis sirve para empezar.
3. **API key de Anthropic** — en https://console.anthropic.com → API Keys → Create Key.
   - Es una cuenta de DESARROLLADOR, distinta a tu plan de chat de Claude.
   - Carga saldo (con USD 5–10 alcanza de sobra para probar; el uso de 80 personas
     moderado ronda USD 65–130 en total).
   - En Settings → Limits pon un límite de gasto mensual y una alerta.

## Paso 1 — Sube el proyecto a GitHub

1. Crea un repositorio nuevo (privado) llamado `casework-pro`.
2. Sube TODO el contenido de esta carpeta (respeta la estructura):
   ```
   casework-deploy/
   ├── api/claude.js        ← backend (la key vive aquí, vía variable de entorno)
   ├── src/App.jsx          ← tu app completa
   ├── src/main.jsx
   ├── index.html
   ├── package.json
   ├── vite.config.js
   ├── .env.example
   └── .gitignore
   ```
   Lo más fácil: en GitHub → "uploading an existing file" → arrastra las carpetas.
   ⚠️ NO subas ningún archivo .env con tu key real (el .gitignore ya lo bloquea).

## Paso 2 — Conecta Vercel

1. En vercel.com → **Add New → Project** → importa tu repo `casework-pro`.
2. Vercel detecta Vite solo. No cambies nada del build.
3. Antes de darle Deploy: **Environment Variables** → agrega:
   - `ANTHROPIC_API_KEY` = tu key (sk-ant-...)
   - (opcional) `MAX_CALLS_PER_HOUR` = 60
4. **Deploy**. En ~1 minuto tienes tu URL: `https://casework-pro.vercel.app`.

## Paso 3 — Prueba de humo (5 min)

En tu URL de Vercel, verifica en orden:
- [ ] Carga la pantalla de inicio con fuentes y estilo.
- [ ] Sube una HdV → genera diagnóstico (primera llamada de IA real).
- [ ] Corre una entrevista corta en Trainer y en Real (cierre incluido).
- [ ] Prueba de Excel → descarga el archivo → fórmulas calculan.
- [ ] HdV adaptada → descarga Word.
- [ ] **En tu celular**: abre la URL → cámara/micrófono piden permiso y funcionan
      (esto es lo que el artifact no podía hacer; aquí sí).

## Paso 4 — Modelos y costos

- El backend enruta: tareas ligeras (términos, research) → **Haiku**;
  entrevista, feedback, HdV → **Sonnet**. Se cambia con las variables
  `MODEL_LIGHT` / `MODEL_DEEP` sin tocar código.
- ⚠️ Los nombres de modelo cambian con el tiempo. Verifica los vigentes en
  https://docs.claude.com (sección Models) y actualiza las variables si hace falta.
- Vigila el consumo en console.anthropic.com → Usage los primeros días.

## Qué quedó pendiente para la FASE 2 (cuando haya usuarios reales)

1. **Login y datos por usuario** → Supabase Auth + RLS (multi-usuario real,
   guardar progreso/historial). Hoy la app no guarda nada entre sesiones.
2. **Límites por usuario de verdad** → el límite actual es por IP y en memoria
   (se reinicia solo); con Supabase se hace por cuenta.
3. **Prompt caching** → reduce ~90% el costo del input repetido. Se activa
   marcando `cache_control` en los bloques del system/prompt largo (ver docs).
4. **Dominio propio** → en Vercel → Domains (ej. casework.com.co).

## Problemas comunes

| Síntoma | Causa probable | Arreglo |
|---|---|---|
| "401/403" al generar | Falta o está mal ANTHROPIC_API_KEY en Vercel | Revisa Environment Variables y redeploya |
| "429 Límite de uso alcanzado" | Tope del rate limit del backend | Sube MAX_CALLS_PER_HOUR |
| "model not found" | Nombre de modelo desactualizado | Actualiza MODEL_LIGHT/MODEL_DEEP con los de docs.claude.com |
| Cámara no pide permiso | Estás en http:// local | En la URL de Vercel (https) sí funciona |
| Funciona local pero no en Vercel | Falta redeploy tras cambiar variables | Deployments → Redeploy |
